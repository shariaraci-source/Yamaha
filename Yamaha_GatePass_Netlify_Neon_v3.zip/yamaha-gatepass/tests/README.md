# Automated tests (developers only – not used by the live site)

Requires PostgreSQL 16 client+server binaries, Node 20+, and Playwright with Google Chrome.

```bash
# once: initdb a local cluster at /var/tmp/gppg/data and start it on port 5544
tests/reset_db.sh                       # fresh database owned by a non-superuser role + the real migration
tests/dev_up.sh                         # local stand-in for Netlify on http://localhost:8788 (real function code)
NODE_PATH=$(npm root -g) node tests/e2e.mjs        # 81 browser checks (multi-PC workflow, security, persistence)
NODE_PATH=$(npm root -g) node tests/idle.mjs       # live-update pause/resume
node tests/api_extra.mjs                           # lockout, session rules, health
```
`devserver.mjs` replaces only the Neon driver (with psql), Netlify Blobs (with a folder) and Netlify routing.
`last_results.json` holds the latest results.
