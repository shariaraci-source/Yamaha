// TEST-ONLY local stand-in for Netlify: serves public/ and runs the REAL function code
// (netlify/functions/api/core.mjs) for /api/*, with:
//   • database  → real PostgreSQL 16, connected as a non-superuser owner role (like Neon's neondb_owner)
//   • blobs     → files kept in a local folder (stand-in for Netlify Blobs)
// Production uses @neondatabase/serverless and @netlify/blobs instead (netlify/functions/api/api.mjs).
import http from 'node:http';
import { spawn } from 'node:child_process';
import { readFileSync, existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { join, extname, dirname } from 'node:path';
import { createHash } from 'node:crypto';
import { createHandler } from '../netlify/functions/api/core.mjs';

const PORT = +(process.env.PORT || 8788);
const ROOT = new URL('..', import.meta.url).pathname;
const BLOBDIR = process.env.BLOBDIR || '/var/tmp/gp_blobs';
const PG = ['-h', process.env.PGHOST || '/var/tmp/gppg', '-p', process.env.PGPORT || '5544', '-U', process.env.PGUSER || 'neondb_owner', '-d', process.env.PGDB || 'neondb'];
export const stats = { queries: 0 };

function query(text, params = []) {
  stats.queries++;
  let sql = text; const vars = [];
  for (let i = params.length; i >= 1; i--) {
    const v = params[i - 1];
    sql = sql.split('$' + i).join(v == null ? 'NULL' : `:'p${i}'`);
    if (v != null) vars.push('-v', `p${i}=${typeof v === 'string' ? v : String(v)}`);
  }
  return new Promise((resolve, reject) => {
    const p = spawn('psql', [...PG, '-X', '-q', '-A', '-t', '-v', 'ON_ERROR_STOP=1', ...vars]);
    let out = '', err = '';
    p.stdout.on('data', (d) => (out += d)); p.stderr.on('data', (d) => (err += d));
    p.on('close', (code) => {
      if (code !== 0) {
        const m = /ERROR:\s+([0-9A-Z]{5}):\s+([^\n]*)/.exec(err) || [];
        const e = new Error(m[2] || err.trim()); e.code = m[1] || 'XX000';
        e.hint = (/HINT:[ \t]+([^\n]*)/.exec(err) || [])[1]; e.detail = (/DETAIL:[ \t]+([^\n]*)/.exec(err) || [])[1];
        return reject(e);
      }
      resolve(/ as r\b/.test(text) ? [{ r: out.replace(/\n$/, '') }] : []);
    });
    p.stdin.end('\\set VERBOSITY verbose\n' + sql + ';\n');
  });
}
const keyFile = (k) => join(BLOBDIR, createHash('sha256').update(k).digest('hex'));
const blobs = {
  async set(k, data) { mkdirSync(BLOBDIR, { recursive: true }); writeFileSync(keyFile(k), Buffer.from(data)); },
  async get(k) { const f = keyFile(k); if (!existsSync(f)) return null; const b = readFileSync(f); return b.buffer.slice(b.byteOffset, b.byteOffset + b.length); },
};
const ENV = { SETUP_CODE: process.env.SETUP_CODE || 'TEST-SETUP-CODE' };
const handle = createHandler({ query, blobs, env: (k) => ENV[k], log: console });
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.png': 'image/png' };
const readBody = (req) => new Promise((r) => { const c = []; req.on('data', (d) => c.push(d)); req.on('end', () => r(Buffer.concat(c))); });

http.createServer(async (req, res) => {
  try {
    const u = new URL(req.url, `http://localhost:${PORT}`);
    if (u.pathname.startsWith('/api/')) {
      const body = ['GET', 'HEAD'].includes(req.method) ? undefined : await readBody(req);
      if (body && body.length > 6 * 1024 * 1024 * 0.75) { res.writeHead(413, { 'Content-Type': 'application/json' }); return res.end('{"error":"Payload too large (Netlify 6 MB limit)"}'); }
      const headers = new Headers(); for (const [k, v] of Object.entries(req.headers)) headers.set(k, Array.isArray(v) ? v.join(', ') : v);
      headers.set('x-nf-client-connection-ip', req.socket.remoteAddress || '');
      const r = await handle(new Request(u, { method: req.method, headers, body }));
      const out = {}; r.headers.forEach((v, k) => { if (k !== 'set-cookie') out[k] = v; });
      const sc = r.headers.getSetCookie(); if (sc.length) out['set-cookie'] = sc;
      res.writeHead(r.status, out); return res.end(Buffer.from(await r.arrayBuffer()));
    }
    const p = u.pathname === '/' ? '/index.html' : u.pathname;
    const f = join(ROOT, 'public', p);
    if (!f.startsWith(join(ROOT, 'public')) || !existsSync(f)) { res.writeHead(404); return res.end('not found'); }
    res.writeHead(200, { 'Content-Type': MIME[extname(f)] || 'application/octet-stream' }); res.end(readFileSync(f));
  } catch (e) { console.error(e); res.writeHead(500); res.end('dev server error'); }
}).listen(PORT, () => console.log('devserver listening on', PORT));
