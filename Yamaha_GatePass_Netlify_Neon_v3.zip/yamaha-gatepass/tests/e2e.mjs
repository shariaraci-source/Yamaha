// End-to-end test: several isolated browser contexts (= separate PCs) on ONE central database.
// Requires: tests/reset_db.sh, tests/dev_up.sh  (see tests/README.md). Runs the real Netlify Function code against real PostgreSQL.
import { createRequire } from 'node:module';
const { chromium } = createRequire(import.meta.url)('playwright'); // uses NODE_PATH for a global install
import { writeFileSync, readFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';

const URL0 = 'http://localhost:8788/';
const results = [];
const check = (name, ok, detail = '') => { results.push({ name, ok: !!ok, detail: String(detail).slice(0, 300) }); console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail && !ok ? '  — ' + detail : ''}`); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const psqlOwner = (sql) => { try { return execFileSync('psql', ['-h', '/var/tmp/gppg', '-p', '5544', '-U', 'neondb_owner', '-d', 'neondb', '-X', '-A', '-t', '-c', sql], { stdio: ['ignore', 'pipe', 'pipe'] }).toString().trim(); } catch (e) { return 'ERROR: ' + e.stderr.toString().trim(); } };
// raw HTTP request from outside any browser (like an attacker's script), optionally with a stolen cookie
const raw = async (method, path, { cookie, headers = {}, body } = {}) => { const r = await fetch(URL0.replace(/\/$/, '') + path, { method, headers: { ...(cookie ? { Cookie: cookie } : {}), ...headers }, body }); let j = {}; try { j = await r.json(); } catch (_) {} return { status: r.status, body: j }; };
const sessionCookie = async (ctx) => { const c = (await ctx.cookies()).find((x) => x.name === 'gp_session'); return c ? `gp_session=${c.value}` : ''; };

const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
const consoleErrors = [];
let S_DEPT_PAINT = null;
async function pc(name) {
  const ctx = await browser.newContext({ acceptDownloads: true, viewport: { width: 1366, height: 860 } });
  const page = await ctx.newPage();
  page.on('pageerror', (e) => consoleErrors.push(`${name}: ${e.message}`));
  page.on('dialog', (d) => d.dismiss());
  await page.goto(URL0);
  await page.waitForFunction(() => !document.querySelector('#view .loading'), null, { timeout: 20000 });
  return { ctx, page, name };
}
const api = (page, method, url, body) => page.evaluate(async ([m, u, b]) => {
  const r = await fetch(u, { method: m, headers: { 'Content-Type': 'application/json' }, body: b === undefined ? undefined : JSON.stringify(b) });
  let j = {}; try { j = await r.json(); } catch (_) {}
  return { status: r.status, body: j };
}, [method, url, body]);
async function login(page, uid, pw) {
  await page.evaluate(() => { location.hash = '#/login'; });
  await page.waitForSelector('#fLogin');
  await page.fill('#fLogin [name=user_id]', uid); await page.fill('#fLogin [name=password]', pw);
  await page.click('#lBtn');
  await page.waitForFunction(() => !location.hash.startsWith('#/login') || document.querySelector('#lErr .alert'), null, { timeout: 40000 });
  await sleep(400);
  return page.evaluate(() => location.hash);
}
async function logout(page) { await page.evaluate(() => fetch('/api/auth/logout', { method: 'POST' })); await page.goto(URL0); await page.waitForSelector('.main .hero, #fLogin, .welcome', { timeout: 10000 }).catch(() => {}); }
async function closeToasts(page) { await page.evaluate(() => { document.querySelector('#toasts').innerHTML = ''; }); }

try {
  /* ============ PC 1: first start, one-time setup ============ */
  const A = await pc('PC1-admin');
  await A.page.waitForFunction(() => location.hash === '#/setup', null, { timeout: 15000 });
  check('Open the URL on PC 1 → application loads (first start shows Initial Setup)', true);
  await A.page.waitForSelector('#fSetup [name=setup_code]');
  await A.page.fill('[name=setup_code]', 'test-setup-code');
  await A.page.fill('[name=user_id]', 'admin'); await A.page.fill('[name=name]', 'Plant Administrator');
  await A.page.fill('[name=password]', 'YamahaPlant2026'); await A.page.fill('[name=confirm_password]', 'YamahaPlant2026');
  await A.page.fill('[name=departments]', 'Production | PROD\nPaint Shop | PAINT\nHR & Admin | HRA');
  await A.page.click('#suBtn');
  await A.page.waitForFunction(() => location.hash === '#/dashboard', null, { timeout: 20000 });
  check('Initial administrator created through secure setup (setup code required) → dashboard', true);
  const again = await api(A.page, 'POST', '/api/setup', { setup_code: 'TEST-SETUP-CODE', user_id: 'intruder', name: 'X', password: 'Abcdefgh1234', confirm_password: 'Abcdefgh1234', departments: ['X'] });
  check('Initial setup cannot be run a second time', again.status === 409, JSON.stringify(again));

  /* employees via Excel/CSV import (UI wizard) */
  const csvPath = '/var/tmp/emp.csv';
  writeFileSync(csvPath, '﻿Staff ID,Employee Name,Designation,Section/Department\nE001,Md. Rahim Uddin,Technician,Production\nE002,Karim Hossain,Painter,Paint Shop\nE003,Salma Akter,Operator,Production\nE001,Duplicate Row,X,Production\n');
  await A.page.evaluate(() => { location.hash = '#/employees'; });
  await A.page.click('#eImp');
  await A.page.setInputFiles('#iwf [name=file]', csvPath);
  await A.page.click('[data-n]');
  await A.page.waitForSelector('[data-go]');
  const pv = await A.page.textContent('.modal-b');
  check('Excel/CSV import preview validates rows (duplicate Staff ID flagged)', /New: 3/.test(pv) && /Errors: 1/.test(pv) && /Duplicate Staff ID in file/.test(pv), pv.slice(0, 200));
  await A.page.click('[data-go]');
  await A.page.waitForSelector('[data-done]'); await A.page.click('[data-done]');
  await A.page.waitForSelector('#eres tbody tr td.pn');
  const empCount = await A.page.$$eval('#eres tbody tr td.pn', (t) => t.map((x) => x.textContent));
  check('Employees imported into the central database', empCount.join() === 'E001,E002,E003', empCount.join());
  // add one employee manually
  await sleep(1500); await A.page.click('#eAdd'); await A.page.waitForSelector('#ef [name=designation]'); await sleep(200);
  for (const [n, v] of [['staff_id', 'E004'], ['name', 'Nasir Ahmed'], ['designation', 'Supervisor']]) { await A.page.fill(`#ef [name=${n}]`, v); if ((await A.page.inputValue(`#ef [name=${n}]`)) !== v) await A.page.fill(`#ef [name=${n}]`, v); }
  await A.page.selectOption('#ef [name=department_id]', { label: 'Production' }); await A.page.click('.modal [data-s]');
  await A.page.waitForSelector('#ef', { state: 'detached', timeout: 15000 }).catch(() => {});
  const efErr = await A.page.$('#efErr') ? await A.page.textContent('#efErr') : '';
  await A.page.waitForFunction(() => document.querySelectorAll('#eres tbody tr td.pn').length === 4, null, { timeout: 15000 }).catch(() => {});
  const emp4 = await api(A.page, 'GET', '/api/employees');
  check('Employee added manually (Employee Database)', emp4.body.total === 4, efErr + ' total=' + emp4.body.total);

  /* users via User Management (UI form → Edge Function) */
  async function createUser(page, u) {
    await page.evaluate(() => { location.hash = '#/users'; }); await page.waitForSelector('#uAdd'); await page.click('#uAdd');
    await page.waitForSelector('#uf'); await sleep(150);   // dialogs move focus to their first field 30 ms after opening
    await page.selectOption('#uf [name=role]', u.role);
    await page.fill('#uf [name=user_id]', u.id); await page.fill('#uf [name=name]', u.name); await page.fill('#uf [name=designation]', u.desig || '');
    await page.fill('#uf [name=password]', u.pw); await page.fill('#uf [name=confirm_password]', u.pw);
    if (u.dept) { await page.selectOption('#uf [name=department_id]', { label: u.dept }); }
    if (u.role === 'DEPT_HEAD') { await page.$$eval('.ad', (xs) => xs.forEach((x) => (x.checked = false))); for (const d of u.appr) { await page.check(`xpath=//label[contains(@class,'chk')][.//span[normalize-space()='${d}']]/input`); } }
    if (u.must) await page.check('#uf [name=must_change_password]');
    await page.click('.modal [data-s]');
    await page.waitForSelector('#uf', { state: 'detached', timeout: 15000 }).catch(async () => { throw new Error('create user failed: ' + await page.textContent('#ufErr') + ' | debug ' + JSON.stringify(await page.evaluate(() => [document.querySelectorAll('#uf').length, document.querySelectorAll('.modal').length, [...document.querySelectorAll('#uf [name=user_id]')].map((x) => x.value), location.hash]))); });
  }
  const users = [
    { id: 'dh.prod', name: 'Production Head', role: 'DEPT_HEAD', dept: 'Production', appr: ['Production'], pw: 'ProdHead2026' },
    { id: 'dh.prod2', name: 'Production Deputy', role: 'DEPT_HEAD', dept: 'Production', appr: ['Production'], pw: 'ProdDep2026' },
    { id: 'dh.paint', name: 'Paint Head', role: 'DEPT_HEAD', dept: 'Paint Shop', appr: ['Paint Shop'], pw: 'PaintHead2026' },
    { id: 'hr1', name: 'HR Officer', role: 'HR_ADMIN', pw: 'HrOfficer2026' },
    { id: 'fh1', name: 'Factory Head', role: 'FACTORY_HEAD', pw: 'Factory2026FH' },
    { id: 'sec1', name: 'Gate Security', role: 'SECURITY', pw: 'Security2026' },
    { id: 'view1', name: 'Viewer With Flag', role: 'VIEWER', pw: 'Viewer2026a', must: true },
  ];
  for (const u of users) await createUser(A.page, u);
  const ulist = await api(A.page, 'GET', '/api/users');
  check('PC 1: administrator created 7 users (roles, departments, approval rights)', ulist.body.rows.length === 8, ulist.body.rows.map((x) => x.user_id).join());
  check('New users without the flag are NOT marked for a forced password change', ulist.body.rows.filter((x) => x.must_change_password).map((x) => x.user_id).join() === 'view1', ulist.body.rows.filter((x) => x.must_change_password).map((x) => x.user_id).join());
  const weak = await api(A.page, 'POST', '/api/users', { user_id: 'weak1', name: 'W', role: 'VIEWER', password: 'abcdefgh', confirm_password: 'abcdefgh', permissions: ['TODAY_VIEW'] });
  check('Server rejects passwords without letters AND numbers', weak.status === 400, JSON.stringify(weak.body));

  /* ============ PC 2: Department Head logs in (normal login, no forced change) ============ */
  const B = await pc('PC2-depthead');
  const hB = await login(B.page, 'dh.prod', 'ProdHead2026');
  check('Open the same URL on PC 2 → same application and database (new user from PC 1 can log in)', hB === '#/dashboard', hB);
  check('Normal user login → no forced password-change screen', hB !== '#/change-password', hB);
  await B.page.evaluate(() => { location.hash = '#/pending'; });
  await B.page.waitForSelector('#pres');

  /* ============ PC 3: employee submits requests without login ============ */
  const C = await pc('PC3-employee');
  await C.page.evaluate(() => { location.hash = '#/employee-pass'; });
  await C.page.fill('#fEmp [name=staff_id]', 'E001'); await C.page.press('#fEmp [name=staff_id]', 'Enter');
  await C.page.waitForFunction(() => /Md\. Rahim Uddin/.test(document.querySelector('#empInfo').textContent));
  check('Staff ID verification auto-fills name / designation / department', (await C.page.inputValue('[name=emp_dept]')) === 'Production');
  await C.page.fill('#fEmp [name=reason]', 'Bank work'); await C.page.fill('#fEmp [name=out_time]', '10:00'); await C.page.fill('#fEmp [name=in_time]', '12:30');
  await C.page.click('#subBtn'); await C.page.waitForSelector('.pno');
  const egp = (await C.page.textContent('.pno')).trim();
  check('Employee Gate Pass created with generated number', /^EGP-\d{8}-0001$/.test(egp), egp);

  await C.page.evaluate(() => { location.hash = '#/material-pass'; });
  await C.page.fill('#fMat [name=staff_id]', 'E001'); await C.page.press('#fMat [name=staff_id]', 'Enter');
  await C.page.waitForFunction(() => /Rahim/.test(document.querySelector('#empInfo').textContent));
  await C.page.selectOption('#fMat [name=material_category]', 'Spare Parts'); await C.page.fill('#fMat [name=material_name]', 'Carburetor assembly');
  await C.page.fill('#fMat [name=quantity]', '4'); await C.page.selectOption('#fMat [name=unit]', 'Pcs');
  await C.page.fill('#fMat [name=reason]', 'Send to vendor for repair'); await C.page.fill('#fMat [name=destination]', 'XYZ Engineering, Gazipur');
  await C.page.fill('#fMat [name=out_time]', '11:00');
  writeFileSync('/var/tmp/invoice.pdf', '%PDF-1.4\n% test attachment\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF\n');
  await C.page.setInputFiles('#fMat [name=attachment]', '/var/tmp/invoice.pdf');
  await C.page.click('#subBtn'); await C.page.waitForSelector('.pno', { timeout: 15000 });
  const mgp = (await C.page.textContent('.pno')).trim();
  check('Material Gate Pass created with attachment uploaded to cloud storage', /^MGP-\d{8}-0001$/.test(mgp), mgp);
  const badType = await C.page.evaluate(async () => { const fd = new FormData(); for (const [k, v] of Object.entries({ staff_id: 'E002', material_category: 'Scrap', material_name: 'Iron', quantity: '1', unit: 'Kg', reason: 'x', destination: 'y', out_time: '09:00', returnable: 'false', submission_key: crypto.randomUUID() })) fd.append(k, v); fd.append('attachment', new File(['MZ'], 'virus.exe', { type: 'application/x-msdownload' })); const r = await fetch('/api/public/material-pass', { method: 'POST', body: fd }); return { s: r.status, j: await r.json() }; });
  check('File upload validation rejects disallowed file types', badType.s === 400 && /PDF, JPG/.test(badType.j.error), JSON.stringify(badType));
  const fakePdf = await C.page.evaluate(async () => { const fd = new FormData(); for (const [k, v] of Object.entries({ staff_id: 'E002', material_category: 'Scrap', material_name: 'Iron', quantity: '1', unit: 'Kg', reason: 'x', destination: 'y', out_time: '09:00', returnable: 'false', submission_key: crypto.randomUUID() })) fd.append(k, v); fd.append('attachment', new File(['MZ\x90\x00 this is an exe'], 'invoice.pdf', { type: 'application/pdf' })); const r = await fetch('/api/public/material-pass', { method: 'POST', body: fd }); return { s: r.status, j: await r.json() }; });
  check('A renamed program disguised as .pdf is rejected (file content check)', fakePdf.s === 400 && /content does not match/.test(fakePdf.j.error), JSON.stringify(fakePdf));
  const big = await C.page.evaluate(async () => { const fd = new FormData(); for (const [k, v] of Object.entries({ staff_id: 'E002', material_category: 'Scrap', material_name: 'Iron', quantity: '1', unit: 'Kg', reason: 'x', destination: 'y', out_time: '09:00', returnable: 'false', submission_key: crypto.randomUUID() })) fd.append(k, v); const b = new Uint8Array(4.2 * 1048576); b.set([0x25, 0x50, 0x44, 0x46]); fd.append('attachment', new File([b], 'big.pdf', { type: 'application/pdf' })); const r = await fetch('/api/public/material-pass', { method: 'POST', body: fd }); return { s: r.status, j: await r.json() }; });
  check('Attachments above 4 MB are refused with a clear message', big.s === 413 && /4 MB/.test(big.j.error), JSON.stringify(big));
  const leftover = psqlOwner("select count(*) from public.gate_passes where material_name = 'Iron'");
  check('Rejected uploads create no gate pass', leftover === '0', leftover);

  /* realtime: PC 2 sees the new requests without reloading */
  const t0 = Date.now();
  await B.page.waitForFunction((n) => document.querySelector('#pres').textContent.includes(n[0]) && document.querySelector('#pres').textContent.includes(n[1]), [egp, mgp], { timeout: 30000 });
  const lag = Date.now() - t0; console.log('      (appeared on PC 2 after', lag, 'ms)');
  check('Create a gate pass on PC 3 → record appears on PC 2 automatically (no reload, within the 15 s refresh)', lag < 20000, `${lag} ms`);

  /* duplicate submission protection */
  const key = await C.page.evaluate(() => crypto.randomUUID());
  const body = { staff_id: 'E003', reason: 'Doctor', out_time: '14:00', in_time: '15:00', submission_key: key };
  const [d1, d2] = await Promise.all([api(C.page, 'POST', '/api/public/employee-pass', body), api(C.page, 'POST', '/api/public/employee-pass', body)]);
  check('Double-click / duplicate submission (same key) creates only ONE gate pass', d1.body.pass.pass_no === d2.body.pass.pass_no && (d1.body.duplicate || d2.body.duplicate), `${d1.body.pass && d1.body.pass.pass_no} / ${d2.body.pass && d2.body.pass.pass_no}`);
  const egp3 = d1.body.pass.pass_no;
  const d3 = await api(C.page, 'POST', '/api/public/employee-pass', { ...body, submission_key: await C.page.evaluate(() => crypto.randomUUID()) });
  check('Identical request with a new form is blocked as duplicate', d3.status === 409, JSON.stringify(d3.body));
  S_DEPT_PAINT = (await api(A.page, 'GET', '/api/departments')).body.find((d) => d.name === 'Paint Shop').id;
  const paint = await api(C.page, 'POST', '/api/public/employee-pass', { staff_id: 'E002', reason: 'Family', out_time: '09:00', in_time: '10:00', submission_key: await C.page.evaluate(() => crypto.randomUUID()) });

  /* approvals: Department Head on PC 2 */
  const rowBtn = (page, passNo, sel) => page.locator(`#pres tr:has(td.pn:has-text("${passNo}")) ${sel}`);
  await rowBtn(B.page, egp, '[data-a]').click();
  await B.page.waitForFunction((n) => !document.querySelector('#pres').textContent.includes(n), egp, { timeout: 10000 });
  await rowBtn(B.page, mgp, '[data-a]').click();
  await B.page.waitForFunction((n) => !document.querySelector('#pres').textContent.includes(n), mgp, { timeout: 10000 });
  check('Department Head approves on PC 2 (one click, no remarks)', true);
  const wrongDept = await api(B.page, 'POST', `/api/approvals/employee/${paint.body.pass.id}/approve`, { stage: 'DEPT' });
  check('Unauthorized user attempts approval (other department) → access denied', wrongDept.status === 403, JSON.stringify(wrongDept.body));
  const noRem = await api(B.page, 'POST', `/api/approvals/employee/${d1.body.pass.id}/reject`, { stage: 'DEPT', remarks: '   ' });
  check('Rejection without remarks is refused by the server', noRem.status === 400, JSON.stringify(noRem.body));

  /* concurrent approvals of the same request by two Department Heads */
  const B2 = await pc('PC2b-deputy');
  await login(B2.page, 'dh.prod2', 'ProdDep2026');
  const [c1, c2] = await Promise.all([api(B.page, 'POST', `/api/approvals/employee/${d1.body.pass.id}/approve`, { stage: 'DEPT' }), api(B2.page, 'POST', `/api/approvals/employee/${d1.body.pass.id}/approve`, { stage: 'DEPT' })]);
  check('Concurrent approval by two users → exactly one succeeds, the other gets "already processed"', [c1.status, c2.status].sort().join() === '200,409', `${c1.status} ${c2.status}`);

  /* ============ PC 1: HR & Admin ============ */
  await logout(A.page);
  const hA = await login(A.page, 'hr1', 'HrOfficer2026');
  check('Log out and log in as another user on PC 1', hA === '#/dashboard', hA);
  const premature = await api(A.page, 'POST', `/api/approvals/employee/${paint.body.pass.id}/approve`, { stage: 'HR' });
  check('Approval stages cannot be bypassed (HR cannot approve before Department Head)', premature.status === 409, JSON.stringify(premature.body));
  await A.page.evaluate(() => { location.hash = '#/pending/hr'; });
  await A.page.waitForFunction((n) => document.querySelector('#pres') && document.querySelector('#pres').textContent.includes(n[0]) && document.querySelector('#pres').textContent.includes(n[1]), [egp, mgp], { timeout: 30000 });
  check('Approve on PC 2 → updated status appears for HR & Admin on PC 1', true);
  await rowBtn(A.page, egp, '[data-a]').click();
  await A.page.waitForFunction((n) => !document.querySelector('#pres').textContent.includes(n), egp);
  await rowBtn(A.page, mgp, '[data-a]').click();
  await A.page.waitForFunction((n) => !document.querySelector('#pres').textContent.includes(n), mgp);
  const egpObj = await api(A.page, 'GET', '/api/passes?' + new URLSearchParams({ type: 'employee', q: egp }));
  check('Employee Gate Pass: Dept Head → HR & Admin → Fully Approved', egpObj.body.rows[0].status === 'APPROVED', egpObj.body.rows[0].status);
  const fApproved = (await api(A.page, 'GET', '/api/passes?' + new URLSearchParams({ type: 'employee', status: 'APPROVED' }))).body;
  const fPending = (await api(A.page, 'GET', '/api/passes?' + new URLSearchParams({ type: 'employee', status: 'PENDING' }))).body;
  const fName = (await api(A.page, 'GET', '/api/passes?' + new URLSearchParams({ type: 'employee', q: 'rahim' }))).body;
  const fDept = (await api(A.page, 'GET', '/api/reports?' + new URLSearchParams({ department_id: String(S_DEPT_PAINT || ''), pageSize: 50 }))).body;
  check('Search and filtering: by status, by employee name, by department', fApproved.rows.every((r) => r.status === 'APPROVED') && fApproved.total >= 1 && fPending.rows.every((r) => r.status.startsWith('PENDING')) && fName.rows.every((r) => /Rahim/.test(r.employee_name)) && fName.total >= 1 && fDept.rows.every((r) => r.department_name === 'Paint Shop'), `approved=${fApproved.total} pending=${fPending.total} name=${fName.total} dept=${fDept.total}`);
  const dup = await api(A.page, 'POST', `/api/approvals/employee/${egpObj.body.rows[0].id}/approve`, {});
  check('Duplicate approval is prevented', dup.status === 409, JSON.stringify(dup.body));
  const mgpObj = (await api(A.page, 'GET', '/api/passes?' + new URLSearchParams({ type: 'material', q: mgp }))).body.rows[0];
  check('Material Gate Pass goes to Factory Head after HR & Admin', mgpObj.status === 'PENDING_FH', mgpObj.status);
  const hrFh = await api(A.page, 'POST', `/api/approvals/material/${mgpObj.id}/approve`, { stage: 'FH' });
  check('HR & Admin cannot give the Factory Head approval → access denied', hrFh.status === 403, JSON.stringify(hrFh.body));

  /* ============ PC 4: Factory Head ============ */
  const D = await pc('PC4-factoryhead');
  await login(D.page, 'fh1', 'Factory2026FH');
  await D.page.evaluate(() => { location.hash = '#/pending/fh'; });
  await D.page.waitForFunction((n) => document.querySelector('#pres') && document.querySelector('#pres').textContent.includes(n), mgp, { timeout: 10000 });
  const att = await D.page.evaluate(async (id) => { const f = await GP_API_DOWNLOAD(`/api/passes/material/${id}/attachment`); return { name: f.name, text: await f.blob.text() }; }, mgpObj.id);
  check('Attachment retrieval: authorized user downloads the original file from cloud storage', /% test attachment/.test(att.text) && att.name === 'invoice.pdf', att.name);
  const anonAtt = await raw('GET', `/api/passes/material/${mgpObj.id}/attachment`);
  check('Attachment cannot be downloaded without login', anonAtt.status === 401, JSON.stringify(anonAtt));
  await rowBtn(D.page, mgp, '[data-a]').click();
  await D.page.waitForFunction((n) => !document.querySelector('#pres').textContent.includes(n), mgp);
  const mFinal = (await api(D.page, 'GET', `/api/passes/material/${mgpObj.id}`)).body;
  check('Material Gate Pass: Dept Head → HR & Admin → Factory Head → Fully Approved, history kept', mFinal.pass.status === 'APPROVED' && mFinal.history.length === 3 && mFinal.history.every((h) => h.approver_name && h.acted_at), JSON.stringify(mFinal.history.map((h) => h.stage + ':' + h.action)));

  const dash = (await api(D.page, 'GET', '/api/dashboard')).body;
  check('Dashboard statistics come from the central database (Factory Head view)', dash.cards && dash.cards.material_total >= 1 && dash.cards.today_approved >= 1 && Array.isArray(dash.trend) && dash.trend.length === 14, JSON.stringify(dash.cards));
  const P = await pc('PC-paint-head');
  await login(P.page, 'dh.paint', 'PaintHead2026');
  const deny = await P.page.evaluate(async (id) => { try { await GP_API_DOWNLOAD(`/api/passes/material/${id}/attachment`); return 'allowed'; } catch (e) { return e.message; } }, mgpObj.id);
  check('Unauthorized user cannot open another department\'s attachment', deny !== 'allowed', deny);
  const peek = await api(P.page, 'GET', `/api/passes/employee/${egpObj.body.rows[0].id}`);
  check('Department-based data restriction (Paint Head cannot view Production pass)', peek.status === 403, JSON.stringify(peek.body).slice(0, 120));

  /* ============ PC 5: Security ============ */
  const E = await pc('PC5-security');
  await login(E.page, 'sec1', 'Security2026');
  await E.page.evaluate(() => { location.hash = '#/today'; });
  await E.page.waitForFunction((n) => document.querySelector('#tres') && document.querySelector('#tres').textContent.includes(n[0]) && document.querySelector('#tres').textContent.includes(n[1]), [egp, mgp], { timeout: 10000 });
  await E.page.fill('#vq', egp); await E.page.click('#vf button');
  await E.page.waitForSelector('.vres');
  check('PC 5: Security sees fully approved passes and verification says AUTHORIZED', /AUTHORIZED TO LEAVE/.test(await E.page.textContent('.vres')));
  const secApprove = await api(E.page, 'POST', `/api/approvals/employee/${paint.body.pass.id}/approve`, {});
  check('Security Personnel cannot approve', secApprove.status === 403, JSON.stringify(secApprove.body));
  await E.page.fill('#vq', egp3); await E.page.click('#vf button'); await sleep(800);
  check('Pending request at the gate → NOT AUTHORIZED', /NOT AUTHORIZED/.test(await E.page.textContent('.vres')));

  await C.ctx.close(); await B2.ctx.close(); await P.ctx.close(); await D.page.evaluate(() => { location.hash = '#/dashboard'; });
  /* ============ passwords ============ */
  await B.page.click('#userChip'); await B.page.click('#userMenu [data-m=pw]');
  await B.page.waitForSelector('#fPw');
  check('Change Password is in the user profile menu, without a forced warning', !(await B.page.$('#fPw ~ .alert, .alert.a-warn')), '');
  await B.page.fill('[name=current_password]', 'WrongPass1'); await B.page.fill('[name=new_password]', 'NewProd2026x'); await B.page.fill('[name=confirm]', 'NewProd2026x'); await B.page.click('#pBtn');
  await B.page.waitForSelector('#pErr .alert');
  check('Wrong current password is rejected', /Current password is incorrect/.test(await B.page.textContent('#pErr')), await B.page.textContent('#pErr'));
  await B.page.fill('[name=current_password]', 'ProdHead2026'); await B.page.fill('[name=new_password]', 'ProdHead2026'); await B.page.fill('[name=confirm]', 'ProdHead2026'); await B.page.click('#pBtn'); await sleep(300);
  check('New password must differ from the current one', /different/.test(await B.page.textContent('#pErr')));
  await B.page.fill('[name=new_password]', 'NewProd2026x'); await B.page.fill('[name=confirm]', 'NewProd2026x'); await B.page.click('#pBtn');
  await B.page.waitForFunction(() => location.hash === '#/dashboard', null, { timeout: 10000 });
  check('Change password voluntarily → success', true);
  await logout(B.page);
  const oldPw = await login(B.page, 'dh.prod', 'ProdHead2026');
  check('Old password no longer works', oldPw === '#/login', oldPw);
  const newPw = await login(B.page, 'dh.prod', 'NewProd2026x');
  check('Login with the new password → successful', newPw === '#/dashboard', newPw);

  const V = await pc('PC-viewer');
  const hV = await login(V.page, 'view1', 'Viewer2026a');
  check('Mandatory password flag enabled → user must change password', hV === '#/change-password' && /must set a new password/.test(await V.page.textContent('#view')), hV);
  const vBlocked = await api(V.page, 'GET', '/api/today');
  check('Server blocks all data until the mandatory change is done', vBlocked.status === 403 && vBlocked.body.code === 'MUST_CHANGE_PASSWORD', JSON.stringify(vBlocked));
  await V.page.fill('[name=current_password]', 'Viewer2026a'); await V.page.fill('[name=new_password]', 'Viewer2026b'); await V.page.fill('[name=confirm]', 'Viewer2026b'); await V.page.click('#pBtn');
  await V.page.waitForFunction(() => location.hash === '#/dashboard', null, { timeout: 10000 });
  await logout(V.page);
  check('After the mandatory change the flag is cleared (next login goes to dashboard)', (await login(V.page, 'view1', 'Viewer2026b')) === '#/dashboard');

  /* admin reset: invalidates the other PC's session, optional flag */
  const H = await pc('PC-hr-second');
  await login(H.page, 'hr1', 'HrOfficer2026');
  const hrTokenBefore = await sessionCookie(H.ctx);
  await logout(A.page); await login(A.page, 'admin', 'YamahaPlant2026');
  const hrId = (await api(A.page, 'GET', '/api/users?q=hr1')).body.rows[0].id;
  await A.page.evaluate(() => { location.hash = '#/users'; });
  await A.page.locator('#ures tr:has(td.pn:has-text("hr1")) [data-a=pw]').click();
  await A.page.waitForSelector('#rpf'); await sleep(150);   // let the dialog's own autofocus happen first
  await A.page.fill('#rpf [name=password]', 'HrReset2026'); await A.page.fill('#rpf [name=confirm_password]', 'HrReset2026'); await A.page.check('#rpf [name=must]');
  await A.page.click('.modal [data-s]');
  const rpClosed = await A.page.waitForSelector('#rpf', { state: 'detached', timeout: 20000 }).then(() => true).catch(() => false);
  if (!rpClosed) throw new Error('reset dialog stayed open: ' + (await A.page.textContent('#rpErr')) + ' | values: ' + (await A.page.inputValue('#rpf [name=password]')));
  check('Administrator resets a password (form never shows the existing password)', true);
  const afterReset = await api(H.page, 'GET', '/api/dashboard');
  check('Password reset invalidates the user\'s existing sessions on other PCs', afterReset.status === 401, JSON.stringify(afterReset.body));
  const stolen = await raw('GET', '/api/auth/me', { cookie: hrTokenBefore });
  const stolen2 = await raw('GET', '/api/dashboard', { cookie: hrTokenBefore });
  check('A copied session cookie from before the reset is rejected by the server', stolen.body.user === null && stolen2.status === 401, JSON.stringify([stolen, stolen2]));
  check('Reset with flag → mandatory change screen', (await login(H.page, 'hr1', 'HrReset2026')) === '#/change-password');
  const ul2 = (await api(A.page, 'GET', '/api/users?q=hr1')).body.rows[0];
  check('Admin cannot see passwords or hashes (no password field in user data)', !JSON.stringify(ul2).match(/password_hash|encrypted|"password"/), Object.keys(ul2).join());
  // reset WITHOUT flag → direct login
  await api(A.page, 'POST', `/api/users/${(await api(A.page, 'GET', '/api/users?q=sec1')).body.rows[0].id}/reset-password`, { password: 'SecNew2026', confirm_password: 'SecNew2026', must_change_password: false });
  const E2 = await pc('PC5b-security');
  check('Reset without the flag → user goes straight to the dashboard', (await login(E2.page, 'sec1', 'SecNew2026')) === '#/dashboard');

  /* deactivation */
  const vId = (await api(A.page, 'GET', '/api/users?q=view1')).body.rows[0].id;
  await api(A.page, 'POST', `/api/users/${vId}/status`, { status: 'INACTIVE' });
  const vAfter = await api(V.page, 'GET', '/api/dashboard');
  check('Deactivated user is logged out everywhere immediately', vAfter.status === 401, JSON.stringify(vAfter.body));
  check('Deactivated user cannot log in', (await login(V.page, 'view1', 'Viewer2026b')) === '#/login');

  /* refresh, persistence */
  await D.page.goto(URL0 + '#/today'); await D.page.reload(); await D.page.waitForSelector('.main .card', { timeout: 10000 });
  const stillIn = await D.page.evaluate(() => location.hash);
  const recs = await api(D.page, 'GET', '/api/reports?' + new URLSearchParams({ from: '', pageSize: 50 }));
  check('Refresh browser → still logged in and existing records remain', stillIn !== '#/login' && recs.body.total >= 1, `${stillIn} total=${recs.body.total}`);

  /* offline / recovery */
  await E2.page.evaluate(() => { location.hash = '#/today'; }); await E2.page.waitForSelector('#tres');
  await E2.ctx.setOffline(true);
  await E2.page.evaluate(() => window.dispatchEvent(new Event('offline')));
  await E2.page.evaluate(() => { location.hash = '#/dashboard'; });
  await E2.page.waitForFunction(() => getComputedStyle(document.querySelector('#offline')).display === 'block', null, { timeout: 15000 });
  const pill = await E2.page.textContent('#hdrConn');
  check('Temporary internet disconnection → connection warning shown', /Offline/.test(pill), pill);
  await E2.ctx.setOffline(false);
  await E2.page.waitForFunction(() => getComputedStyle(document.querySelector('#offline')).display === 'none', null, { timeout: 30000 });
  await E2.page.evaluate(() => { location.hash = '#/reports'; }); await sleep(300); await E2.page.evaluate(() => { location.hash = '#/today'; });
  const back = await E2.page.waitForFunction(() => /Employee Gate Passes/.test(document.querySelector('#view').textContent), null, { timeout: 20000 }).then(() => true).catch(() => false);
  check('Connection restored → automatic recovery, data loads again', back && /Live|Online/.test(await E2.page.textContent('#hdrConn')), (await E2.page.textContent('#view')).replace(/\s+/g, ' ').slice(0, 200) + ' | ' + await E2.page.textContent('#hdrConn'));

  /* reports export */
  await A.page.evaluate(() => { location.hash = '#/reports'; }); await A.page.waitForSelector('#rX');
  const [dl] = await Promise.all([A.page.waitForEvent('download'), A.page.click('#rX')]);
  const csv = readFileSync(await dl.path(), 'utf8');
  check('Export reports → CSV/Excel file with correct data', csv.includes(egp) && csv.includes(mgp) && csv.includes('Approved – Fully Approved') && csv.includes('Carburetor assembly'), dl.suggestedFilename());
  const [dl2] = await Promise.all([A.page.waitForEvent('download'), A.page.evaluate(() => download('/api/employees/export'))]);
  check('Employee export to Excel', /E001,Md\. Rahim Uddin,Technician,Production,ACTIVE/.test(readFileSync(await dl2.path(), 'utf8')));

  /* backup + safe merge restore + migration from the single-PC edition */
  await A.page.evaluate(() => { location.hash = '#/settings/backup'; }); await A.page.waitForSelector('#bkDlF');
  const [bk] = await Promise.all([A.page.waitForEvent('download', { timeout: 20000 }), A.page.click('#bkDlF')]);
  const bkJson = JSON.parse(readFileSync(await bk.path(), 'utf8'));
  check('Backup contains employees, passes, approvals, users (no passwords) and attachment files', bkJson.employees.length === 4 && bkJson.passes.material[0].attachment_data && bkJson.approvals.length >= 5 && !JSON.stringify(bkJson.users).includes('password_hash'), `${bkJson.employees.length} emp, ${bkJson.approvals.length} approvals`);
  const bkFile = '/var/tmp/backup.json'; writeFileSync(bkFile, JSON.stringify(bkJson));
  await A.page.setInputFiles('#bkFile', bkFile); await A.page.click('#bkRestore');
  await A.page.click('.modal [data-ok]');
  await A.page.waitForSelector('.modal .chip-sum', { timeout: 20000 });
  const mergeTxt = await A.page.textContent('.modal .chip-sum');
  check('Restoring a backup over live data adds nothing and overwrites nothing (safe merge)', /Gate passes added: 0/.test(mergeTxt) && /Already existed: 4/.test(mergeTxt) && /Log entries: 0/.test(mergeTxt), mergeTxt);
  await A.page.click('.modal [data-x]');
  const old = { schema: 1, ids: {}, counters: { 'EGP-20261020': 7 }, departments: [{ id: 1, name: 'Production', code: 'PROD', active: 1 }, { id: 9, name: 'Store', code: 'STORE', active: 1 }],
    employees: [{ id: 1, staff_id: 'E001', name: 'Md. Rahim Uddin', designation: 'Technician', department_id: 1, status: 'ACTIVE' }, { id: 2, staff_id: 'S900', name: 'Old Store Keeper', designation: 'Keeper', department_id: 9, status: 'ACTIVE' }],
    users: [{ id: 1, user_id: 'oldadmin', name: 'Old Admin', role: 'ADMIN', password_hash: 's256$x' }],
    passes: { employee: [{ id: 1, pass_no: 'EGP-20261020-0007', request_date: '2026-10-20', staff_id: 'S900', employee_name: 'Old Store Keeper', designation: 'Keeper', department_id: 9, department_name: 'Store', reason: 'Old record', out_time: '09:00', in_time: '10:00', status: 'APPROVED', created_at: '2026-10-20 08:55:00', updated_at: '2026-10-20 09:20:00', dept_action: 'APPROVED', dept_by: 3, dept_by_user_id: 'x', dept_by_name: 'Old DH', dept_at: '2026-10-20 09:00:00', hr_action: 'APPROVED', hr_by: 4, hr_by_user_id: 'y', hr_by_name: 'Old HR', hr_at: '2026-10-20 09:20:00' }], material: [] },
    approvals: [{ id: 1, pass_type: 'EMPLOYEE', pass_id: 1, pass_no: 'EGP-20261020-0007', stage: 'DEPT', action: 'APPROVED', approver_name: 'Old DH', acted_at: '2026-10-20 09:00:00' }, { id: 2, pass_type: 'EMPLOYEE', pass_id: 1, pass_no: 'EGP-20261020-0007', stage: 'HR', action: 'APPROVED', approver_name: 'Old HR', acted_at: '2026-10-20 09:20:00' }],
    logs: [{ id: 1, at: '2026-10-20 08:55:00', action: 'SUBMIT', entity: 'EMPLOYEE', entity_id: 'EGP-20261020-0007' }], settings: { company_name_en: 'ACI Motors Limited' } };
  writeFileSync('/var/tmp/old_singlepc.json', JSON.stringify(old));
  await A.page.setInputFiles('#bkFile', '/var/tmp/old_singlepc.json'); await A.page.click('#bkRestore'); await A.page.click('.modal [data-ok]');
  await A.page.waitForSelector('.modal .chip-sum', { timeout: 20000 });
  const migTxt = await A.page.textContent('.modal-b');
  check('Single-PC edition backup migrates: keeps pass numbers + approval history, lists users to recreate', /Gate passes added: 1/.test(migTxt) && /Employees added: 1/.test(migTxt) && /oldadmin/.test(migTxt), migTxt.slice(0, 250));
  const mig = (await api(A.page, 'GET', '/api/reports?' + new URLSearchParams({ from: '2026-10-01', pass_no: 'EGP-20261020-0007' }))).body.rows[0];
  check('Migrated pass keeps number, status, approvers and Dhaka timestamps', mig && mig.status === 'APPROVED' && mig.hr_by_name === 'Old HR' && mig.hr_at === '2026-10-20 09:20:00', JSON.stringify(mig && [mig.status, mig.hr_at]));

  /* audit log */
  const want = ['LOGIN', 'DEPT_APPROVE', 'HR_APPROVE', 'FH_APPROVE', 'USER_PASSWORD_RESET', 'EMPLOYEE_IMPORT', 'BACKUP_IMPORT', 'LOGIN_FAILED', 'PASSWORD_CHANGE', 'USER_CREATE', 'SUBMIT', 'INITIAL_SETUP'];
  const missing = []; for (const a of want) { const r = (await api(A.page, 'GET', '/api/logs?q=' + a)).body; if (!r.rows.some((l) => l.action === a)) missing.push(a); }
  check('Audit log records setup, logins, submissions, approvals, resets, imports', missing.length === 0, 'missing: ' + missing.join());

  /* database permissions (direct access, bypassing the app) */
  const html = readFileSync(new URL('../public/index.html', import.meta.url), 'utf8');
  check('No database URL, password or secret in the website files', !/postgres(ql)?:\/\/|neon\.tech|DATABASE_URL\s*=|SETUP_CODE\s*=|npg_/i.test(html));
  const noLogin = await Promise.all(['/api/dashboard', '/api/users', '/api/employees', '/api/reports', '/api/logs', '/api/backup/part?part=meta', '/api/approvals/pending'].map((u) => raw('GET', u)));
  check('Every protected API endpoint refuses requests without login (401)', noLogin.every((r) => r.status === 401), noLogin.map((r) => r.status).join());
  const notListed = psqlOwner("select public.api_call(null, 'gp_svc_set_status', '{}'::jsonb, null)");
  check('Internal functions cannot be reached through the API dispatcher (allow-list)', /API function not available/.test(notListed), notListed.slice(0, 160));
  const adminCookie = await sessionCookie(A.ctx);
  const csrf1 = await raw('POST', '/api/users', { cookie: adminCookie, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ user_id: 'evil1', name: 'E', role: 'ADMIN', password: 'Evil2026xx', confirm_password: 'Evil2026xx' }) });
  const csrf2 = await raw('POST', '/api/users', { cookie: adminCookie, headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'GatePass', Origin: 'https://evil.example.com' }, body: JSON.stringify({ user_id: 'evil2', name: 'E', role: 'ADMIN', password: 'Evil2026xx', confirm_password: 'Evil2026xx' }) });
  check('Cross-site request forgery is blocked (missing header / foreign origin)', csrf1.status === 403 && csrf2.status === 403, `${csrf1.status} ${csrf2.status}`);
  const secUser = await raw('GET', '/api/users', { cookie: await sessionCookie(E2.ctx) });
  check('A logged-in non-admin cannot use User Management (403)', secUser.status === 403, JSON.stringify(secUser.body));
  const hashes = psqlOwner("select count(*) from auth.users where password_hash like '$2a$10$%'") + '/' + psqlOwner('select count(*) from auth.users');
  const tokens = psqlOwner("select count(*) from auth.sessions where token_hash ~ '^[0-9a-f]{64}$'") + '/' + psqlOwner('select count(*) from auth.sessions');
  check('Passwords stored only as bcrypt hashes; session tokens stored only as SHA-256 hashes', hashes.split('/')[0] === hashes.split('/')[1] && tokens.split('/')[0] === tokens.split('/')[1], `bcrypt ${hashes}, tokens ${tokens}`);
  const injection = await api(E2.page, 'GET', '/api/public/employee/' + encodeURIComponent("E001'; drop table public.employees; --"));
  const stillThere = await api(A.page, 'GET', '/api/employees');
  check('SQL injection attempt is treated as plain text', injection.status === 404 && stillThere.body.total >= 3, JSON.stringify(injection.body).slice(0, 120));

  /* logout & old token */
  const tok = await sessionCookie(D.ctx);
  const httpOnly = (await D.ctx.cookies()).find((x) => x.name === 'gp_session');
  const jsSees = await D.page.evaluate(() => document.cookie.includes('gp_session'));
  check('Session cookie is HttpOnly + SameSite=Strict (page scripts cannot read it)', httpOnly && httpOnly.httpOnly && httpOnly.sameSite === 'Strict' && !jsSees, JSON.stringify(httpOnly && { h: httpOnly.httpOnly, s: httpOnly.sameSite }));
  await logout(D.page);
  const reuse = await raw('GET', '/api/dashboard', { cookie: tok });
  check('Secure logout: the session cookie cannot be reused afterwards', reuse.status === 401, JSON.stringify(reuse));

  /* persistence: browser closed completely, then a new deployment (server restarted) */
  const passTotal = (await api(A.page, 'GET', '/api/reports?pageSize=1')).body.total;
  await E2.ctx.close();
  execFileSync('sh', [new URL('./dev_up.sh', import.meta.url).pathname]);   // = new deploy: function code reloaded, database untouched
  const F = await pc('PC-after-redeploy');
  check('After browser closure + redeployment: login works and all records are still there', (await login(F.page, 'admin', 'YamahaPlant2026')) === '#/dashboard' && (await api(F.page, 'GET', '/api/reports?pageSize=1')).body.total === passTotal, `total=${passTotal}`);
  const aStill = await api(A.page, 'GET', '/api/auth/me');
  check('Existing logged-in sessions survive a redeployment', aStill.body.user && aStill.body.user.user_id === 'admin');

  /* screenshots for the record */
  await A.page.evaluate(() => { location.hash = '#/dashboard'; }); await sleep(1200); await A.page.screenshot({ path: '/var/tmp/shot_dashboard.png' });
  await E.page.evaluate(() => { location.hash = '#/today'; }); await sleep(1200); await E.page.screenshot({ path: '/var/tmp/shot_today.png' });
  check('No JavaScript errors in any browser', consoleErrors.length === 0, consoleErrors.join(' | '));
} catch (e) {
  check('Test run completed without crashing', false, e.stack || e.message);
} finally {
  await browser.close();
  writeFileSync('/var/tmp/e2e_results.json', JSON.stringify(results, null, 1));
  const f = results.filter((r) => !r.ok).length;
  console.log(`\n${results.length - f} passed, ${f} failed`);
}
