// Extra server checks (run after e2e.mjs on the same database): login lockout, session rules, health.
import { execFileSync } from 'node:child_process';
import { readFileSync, writeFileSync } from 'node:fs';
const B = 'http://localhost:8788';
const out = [];
const check = (name, ok, d = '') => { out.push({ name, ok: !!ok, detail: String(d).slice(0, 300) }); console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${ok ? '' : '  — ' + d}`); };
const db = (sql) => execFileSync('psql', ['-h', '/var/tmp/gppg', '-p', '5544', '-U', 'neondb_owner', '-d', 'neondb', '-X', '-A', '-t', '-c', sql]).toString().trim();
async function req(method, path, { cookie, body } = {}) {
  const r = await fetch(B + path, { method, headers: { 'X-Requested-With': 'GatePass', 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const sc = r.headers.getSetCookie().find((c) => c.startsWith('gp_session=') && !c.startsWith('gp_session=;'));
  let j = {}; try { j = await r.json(); } catch (_) {}
  return { status: r.status, body: j, cookie: sc ? sc.split(';')[0] : null };
}
const login = (u, p) => req('POST', '/api/auth/login', { body: { user_id: u, password: p } });

const h = await req('GET', '/api/health');
check('Health endpoint confirms database connection and migration version', h.body.database === 'connected' && h.body.schema_versions.includes('001_gatepass_schema'), JSON.stringify(h.body));

// lockout
const admin = await login('admin', 'YamahaPlant2026');
await req('POST', '/api/users', { cookie: admin.cookie, body: { user_id: 'lock.test', name: 'Lock Test', role: 'VIEWER', password: 'LockTest2026', confirm_password: 'LockTest2026', permissions: ['TODAY_VIEW'] } });
for (let i = 0; i < 5; i++) await login('lock.test', 'wrong-' + i);
const locked = await login('lock.test', 'LockTest2026');
check('5 wrong passwords lock the User ID for 15 minutes (even the right password is refused)', locked.status === 429 && /Too many/.test(locked.body.error), JSON.stringify(locked.body));
db("update audit_logs set at = at - interval '16 minutes' where action = 'LOGIN_FAILED' and lower(user_id) = 'lock.test'");
check('After 15 minutes the user can log in again', (await login('lock.test', 'LockTest2026')).status === 200);

// change own password signs out other computers, keeps this one
const pc1 = await login('lock.test', 'LockTest2026'); const pc2 = await login('lock.test', 'LockTest2026');
const ch = await req('POST', '/api/auth/change-password', { cookie: pc1.cookie, body: { current_password: 'LockTest2026', new_password: 'LockTest2027', confirm: 'LockTest2027' } });
const s1 = await req('GET', '/api/auth/me', { cookie: pc1.cookie }); const s2 = await req('GET', '/api/auth/me', { cookie: pc2.cookie });
check('Changing your own password keeps this computer logged in and signs out the others', ch.status === 200 && s1.body.user && s2.body.user === null, JSON.stringify([ch.status, !!s1.body.user, s2.body.user]));
const weak = await req('POST', '/api/auth/change-password', { cookie: pc1.cookie, body: { current_password: 'LockTest2027', new_password: 'onlyletters', confirm: 'onlyletters' } });
check('New password must contain letters and numbers (server-side)', weak.status === 400 && /letters and numbers/.test(weak.body.error), JSON.stringify(weak.body));

// idle timeout 8 h
db("update auth.sessions set last_seen_at = now() - interval '8 hours 1 minute' where user_id = (select id from profiles where user_id = 'lock.test')");
const idle = await req('GET', '/api/dashboard', { cookie: pc1.cookie });
check('Session ends automatically after 8 hours without activity (server-side)', idle.status === 401, JSON.stringify(idle.body));

// unknown user: same message as wrong password
const u1 = await login('no.such.user', 'Whatever2026'); const u2 = await login('admin', 'Wrong2026xx');
check('Unknown User ID and wrong password give the same message (no account guessing)', u1.status === 401 && u2.status === 401 && u1.body.error === u2.body.error, `${u1.body.error} | ${u2.body.error}`);

const prev = JSON.parse(readFileSync('/var/tmp/e2e_results.json', 'utf8'));
writeFileSync('/var/tmp/e2e_results.json', JSON.stringify([...prev, ...out], null, 1));
