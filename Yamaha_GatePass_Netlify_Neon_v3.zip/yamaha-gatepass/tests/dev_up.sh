#!/bin/sh
# TEST ONLY: (re)start the local dev server on port 8788
[ -f /var/tmp/dev.pid ] && kill $(cat /var/tmp/dev.pid) 2>/dev/null; sleep 0.3
cd "$(dirname "$0")/.." && nohup node tests/devserver.mjs > /var/tmp/dev.log 2>&1 &
echo $! > /var/tmp/dev.pid
for i in 1 2 3 4 5 6 7 8 9 10; do grep -q listening /var/tmp/dev.log 2>/dev/null && exit 0; sleep 0.5; done
cat /var/tmp/dev.log; exit 1
