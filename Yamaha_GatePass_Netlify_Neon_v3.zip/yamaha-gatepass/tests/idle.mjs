// Change polling pauses after 30 min without activity and resumes on mouse movement (uses Playwright's fake clock)
import { createRequire } from 'node:module';
import { writeFileSync, readFileSync } from 'node:fs';
const { chromium } = createRequire(import.meta.url)('playwright');
const b = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
const page = await (await b.newContext()).newPage();
const out = [];
const check = (name, ok, d = '') => { out.push({ name, ok: !!ok, detail: d }); console.log(`${ok ? 'PASS' : 'FAIL'}  ${name} ${ok ? '' : d}`); };
const real = (ms) => new Promise((r) => setTimeout(r, ms));
async function advance(ms) { for (let t = 0; t < ms; t += 5000) { await page.clock.runFor(Math.min(5000, ms - t)); await real(120); } }
let syncCalls = 0; page.on('request', (r) => { if (r.url().includes('/api/public/sync')) syncCalls++; });
await page.clock.install();
await page.goto('http://localhost:8788/#/login'); await page.waitForSelector('#fLogin');
await advance(5000);
check('Header shows Live while the screen is in use', /Live/.test(await page.textContent('#hdrConn')), await page.textContent('#hdrConn'));
await advance(31 * 60e3);
const n1 = syncCalls; await advance(10 * 60e3); const n2 = syncCalls;
check('After 30 min without activity, polling stops (database may sleep)', /Paused/.test(await page.textContent('#hdrConn')) && n2 === n1, `${await page.textContent('#hdrConn')} calls ${n1}->${n2}`);
await page.mouse.move(200, 200); await page.mouse.move(300, 300); await advance(3000);
check('Moving the mouse resumes live updates immediately', /Live/.test(await page.textContent('#hdrConn')) && syncCalls > n2, await page.textContent('#hdrConn'));
await b.close();
const prev = JSON.parse(readFileSync('/var/tmp/e2e_results.json', 'utf8'));
writeFileSync('/var/tmp/e2e_results.json', JSON.stringify([...prev, ...out], null, 1));
