#!/bin/sh
# TEST ONLY: fresh database owned by a non-superuser role (like Neon's neondb_owner) + the real migration
set -e
cd "$(dirname "$0")/.."
P="-h ${PGHOST:-/var/tmp/gppg} -p ${PGPORT:-5544}"
psql $P -U postgres -q -c "drop database if exists neondb with (force)" >/dev/null
psql $P -U postgres -q -c "do \$\$ begin if not exists (select 1 from pg_roles where rolname='neondb_owner') then create role neondb_owner login createdb createrole nosuperuser; end if; end \$\$" -c "create database neondb owner neondb_owner" >/dev/null
psql $P -U neondb_owner -d neondb -q -v ON_ERROR_STOP=1 -1 -f db/migrations/001_gatepass_schema.sql
rm -rf /var/tmp/gp_blobs
echo "database ready"
