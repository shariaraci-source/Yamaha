# Yamaha Factory – Gate Pass System · v3 (Netlify + Neon PostgreSQL)

ACI Motors Limited · Yamaha Manufacturing Plant · Bachchhar, Rajabari, Sreepur, Gazipur

One permanent website URL, one central Neon PostgreSQL database, any number of authorised computers. The screens, workflow and business rules are unchanged from the previous version; Supabase has been removed completely.

**Start here:** `docs/DEPLOYMENT_GUIDE.md` → `docs/LIVE_CHECKLIST.md` → `docs/ADMIN_GUIDE.md` → `docs/USER_MANUAL.md`
Also: `docs/CHANGES.md` (what changed and why), `docs/BACKUP_RECOVERY.md`, `docs/TEST_REPORT.md`, `.env.example`.

## Architecture
```
Browser (any PC) ──HTTPS──► Netlify CDN: public/index.html          (no keys, no secrets)
        │
        └── /api/* ───────► Netlify Function "api"                  (netlify/functions/api)
                               │  DATABASE_URL, SETUP_CODE from Netlify environment variables
                               ├── Neon PostgreSQL ── public.api_call(session, function, args)
                               │       • checks the session, allows only listed functions
                               │       • all rules: roles, departments, approval stages, audit log
                               └── Netlify Blobs "pass-attachments"  (attachment files, private)
```

## Project files
| Path | Purpose |
|---|---|
| `public/index.html` | The application (existing UI + connection layer) |
| `netlify/functions/api/api.mjs` | Function entry: connects Neon driver + Netlify Blobs |
| `netlify/functions/api/core.mjs` | All API routes, login/cookies, uploads, CSRF protection, error handling |
| `db/migrations/001_gatepass_schema.sql` | Complete database: tables, keys, constraints, indexes, auth, workflow functions |
| `netlify.toml` | Build, functions, security headers |
| `package.json` | Function dependencies (`@neondatabase/serverless`, `@netlify/blobs`) |
| `.env.example` | The two environment variables you set in Netlify |
| `docs/` | Guides, checklist, test report |
| `tests/` | Automated test harness (developers only) |

## Environment variables (Netlify)
| Key | Required | What |
|---|---|---|
| `DATABASE_URL` | yes | Neon pooled connection string (secret). `NETLIFY_DATABASE_URL` is accepted too |
| `SETUP_CODE` | for first setup | One-time code to create the first administrator |

## Security summary
No secrets in the browser · passwords as bcrypt hashes · session tokens stored as SHA-256 hashes in HttpOnly/Secure/SameSite=Strict cookies · 8 h idle / 72 h absolute session limit · login lockout · server-side permission, department and stage checks for every request · fixed allow-list of callable database functions · parameterised SQL only · CSRF header + origin check · upload type, content and size checks · private file storage served only after a permission check · audit log incl. IP addresses · CSP / anti-framing / HSTS headers.
