// Yamaha Gate Pass – API server logic (runs as a Netlify Function).
// No secrets in here: the database URL and setup code come from environment variables via `deps`.
// Dependencies are injected so the same code runs in production (Neon + Netlify Blobs) and in the tests.

import { createHash, randomBytes, randomUUID, timingSafeEqual } from 'node:crypto';

const COOKIE = 'gp_session';
const SESSION_MAX_AGE = 72 * 3600;          // absolute session lifetime (seconds); idle logout after 8 h is enforced in the database
const MAX_FILE = 4 * 1024 * 1024;           // Netlify buffered payload limit is 6 MB incl. Base64 overhead → 4 MB files
const MAX_JSON = 5 * 1024 * 1024;
const FILE_TYPES = {
  pdf: { mime: 'application/pdf', magic: [[0x25, 0x50, 0x44, 0x46]] },
  jpg: { mime: 'image/jpeg', magic: [[0xff, 0xd8, 0xff]] },
  jpeg: { mime: 'image/jpeg', magic: [[0xff, 0xd8, 0xff]] },
  png: { mime: 'image/png', magic: [[0x89, 0x50, 0x4e, 0x47]] },
  xlsx: { mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', magic: [[0x50, 0x4b, 0x03, 0x04]] },
  docx: { mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', magic: [[0x50, 0x4b, 0x03, 0x04]] },
};
const LABELS = { PENDING_DEPT: 'Pending – Department Head Approval', PENDING_HR: 'Pending – HR & Admin Approval', PENDING_FH: 'Pending – Factory Head Approval', APPROVED: 'Approved – Fully Approved', REJECTED_DEPT: 'Rejected – Department Head', REJECTED_HR: 'Rejected – HR & Admin', REJECTED_FH: 'Rejected – Factory Head' };

class HttpError extends Error { constructor(status, message, extra) { super(message); this.status = status; this.extra = extra; } }
const sha256 = (s) => createHash('sha256').update(String(s)).digest('hex');
const todayDhaka = () => new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Dhaka', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
const csv = (rows) => '﻿' + rows.map((r) => r.map((c) => { const s = c == null ? '' : String(c); return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; }).join(',')).join('\r\n');
const BASE_HEADERS = { 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'same-origin' };
const json = (status, body, extra = {}) => new Response(JSON.stringify(body ?? {}), { status, headers: { ...BASE_HEADERS, 'Content-Type': 'application/json; charset=utf-8', ...extra } });
const fileResponse = (body, filename, type) => new Response(body, { status: 200, headers: { ...BASE_HEADERS, 'Content-Type': type, 'Content-Disposition': `attachment; filename="${String(filename).replace(/[^\w.\- ()]+/g, '_')}"; filename*=UTF-8''${encodeURIComponent(filename)}` } });

function cookieValue(req, name) {
  const h = req.headers.get('cookie') || '';
  for (const part of h.split(';')) { const i = part.indexOf('='); if (i > 0 && part.slice(0, i).trim() === name) return decodeURIComponent(part.slice(i + 1).trim()); }
  return '';
}
const sessionCookie = (token, secure) => `${COOKIE}=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${SESSION_MAX_AGE}${secure ? '; Secure' : ''}`;
const clearCookie = (secure) => `${COOKIE}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0${secure ? '; Secure' : ''}`;

/** Map a PostgreSQL error to an HTTP error. Our SQL functions raise SQLSTATE GP4xx with user-facing messages. */
function dbError(e) {
  const code = String(e?.code || '');
  if (/^GP\d{3}$/.test(code)) return new HttpError(+code.slice(2), e.message, e.hint ? { code: e.hint } : undefined);
  if (/^23/.test(code)) return new HttpError(400, 'The data could not be saved because it is invalid or duplicated.' + (e.detail ? ' ' + e.detail : ''));
  if (code === '22P02' || code === '22007' || code === '22008') return new HttpError(400, 'Invalid value in the request.');
  return null;
}

function safeName(name) { return String(name || 'file').replace(/[^A-Za-z0-9._-]+/g, '_').replace(/^_+/, '').slice(-120) || 'file'; }

export function createHandler(deps) {
  const { query, blobs, env, log = console } = deps;

  async function sql(text, params) {
    try { return await query(text, params); }
    catch (e) {
      const he = dbError(e);
      if (he) throw he;
      log.error('[db]', e?.code || '', e?.message || e);
      throw new HttpError(503, 'The database is not reachable at the moment. Please try again in a few seconds.');
    }
  }
  const parse = (v) => (typeof v === 'string' ? JSON.parse(v) : v);
  async function call(ctx, fn, args = {}) {
    const rows = await sql('select public.api_call($1, $2, $3::jsonb, $4)::text as r', [ctx.tokenHash || null, fn, JSON.stringify(args), ctx.ip || null]);
    return parse(rows[0].r);
  }

  async function storeFile(file) {
    if (!file || typeof file.arrayBuffer !== 'function' || !file.size) return null;
    const name = String(file.name || 'file');
    const ext = (name.toLowerCase().match(/\.([a-z0-9]+)$/) || [])[1];
    const t = FILE_TYPES[ext];
    if (!t) throw new HttpError(400, 'Attachment must be a PDF, JPG, PNG, XLSX or DOCX file.');
    if (file.size > MAX_FILE) throw new HttpError(413, 'Attachment must be smaller than 4 MB.');
    const ab = await file.arrayBuffer(); const buf = new Uint8Array(ab);
    if (!t.magic.some((m) => m.every((b, i) => buf[i] === b))) throw new HttpError(400, 'The attachment content does not match its file type. Please attach a genuine PDF, JPG, PNG, XLSX or DOCX file.');
    const path = `incoming/${randomUUID()}/${safeName(name)}`;
    await blobs.set(path, ab, { metadata: { name: name.slice(0, 150), type: t.mime, size: buf.length } });
    await sql('select public._gp_file_put($1, $2, $3)', [path, buf.length, t.mime]);
    return { path, name: name.slice(0, 150), type: t.mime };
  }

  // ---------- routes ----------
  const R = [];
  const on = (method, pattern, fn) => R.push([method, new RegExp('^' + pattern.replace(/:(\w+)/g, '([^/]+)') + '$'), fn]);
  const rpc = (fn, args) => (c) => call(c, fn, typeof args === 'function' ? args(c) : args || {});

  on('GET', '/api/health', rpc('gp_health'));
  on('GET', '/api/public/info', rpc('gp_public_info'));
  on('GET', '/api/public/sync', rpc('gp_sync_state'));
  on('GET', '/api/public/employee/:id', rpc('gp_public_employee', (c) => ({ p_staff_id: c.p[0] })));
  on('POST', '/api/public/employee-pass', rpc('gp_submit_pass', (c) => { const b = { ...c.b }; delete b.attachment; return { p_type: 'employee', p: b }; }));
  on('POST', '/api/public/material-pass', async (c) => {
    const b = { ...c.b }; const f = b.attachment; delete b.attachment;
    for (const [k, v] of Object.entries(b)) if (typeof v !== 'string') delete b[k];
    if (f && typeof f === 'object' && f.size) b.attachment = await storeFile(f);
    return call(c, 'gp_submit_pass', { p_type: 'material', p: b });
  });
  on('GET', '/api/public/track', rpc('gp_track', (c) => ({ p_pass_no: c.q.pass_no || '', p_staff_id: c.q.staff_id || '' })));

  on('GET', '/api/setup/status', async (c) => ({ ...(await call(c, 'gp_setup_status')), code_required: true }));
  on('POST', '/api/setup', async (c) => {
    const expected = String(env('SETUP_CODE') || '').trim().toUpperCase();
    if (!expected) throw new HttpError(503, 'The setup code has not been configured on the server yet (Netlify environment variable SETUP_CODE). See the deployment guide.');
    const st = await call(c, 'gp_setup_status');
    if (!st.setup_required) throw new HttpError(409, 'Initial setup has already been completed. Please log in.');
    const given = Buffer.from(String(c.b.setup_code || '').trim().toUpperCase()); const exp = Buffer.from(expected);
    if (given.length !== exp.length || !timingSafeEqual(given, exp)) throw new HttpError(403, 'The one-time setup code is not correct.');
    const depts = (Array.isArray(c.b.departments) ? c.b.departments : String(c.b.departments || '').split('\n')).map((x) => String(x).trim()).filter(Boolean).slice(0, 200);
    await sql('select public.gp_setup($1::jsonb)::text', [JSON.stringify({ ...c.b, departments: depts, setup_code: undefined })]);
    return login(c, c.b.user_id, c.b.password);
  });

  async function login(c, userId, password) {
    const token = randomBytes(32).toString('base64url');
    const rows = await sql('select public.gp_auth_login($1, $2, $3, $4, $5)::text as r', [String(userId || ''), String(password || ''), sha256(token), c.ip || null, (c.req.headers.get('user-agent') || '').slice(0, 300)]);
    const r = parse(rows[0].r);
    if (!r.ok) throw new HttpError(r.status || 401, r.error);
    c.setCookie = sessionCookie(token, c.secure);
    return { ok: true, must_change_password: r.must_change_password };
  }
  on('POST', '/api/auth/login', (c) => login(c, c.b.user_id, c.b.password));
  on('POST', '/api/auth/logout', async (c) => {
    if (c.tokenHash) await sql('select public.gp_auth_logout($1, $2)', [c.tokenHash, c.ip || null]);
    c.setCookie = clearCookie(c.secure);
    return { ok: true };
  });
  on('GET', '/api/auth/me', async (c) => {
    if (!c.tokenHash) return { user: null };
    try { return { user: await call(c, 'gp_me') }; }
    catch (e) { if (e.status === 401) { c.setCookie = clearCookie(c.secure); return { user: null }; } throw e; }
  });
  on('POST', '/api/auth/change-password', rpc('gp_change_password', (c) => ({ p: c.b })));

  on('GET', '/api/departments', rpc('gp_departments'));
  on('GET', '/api/passes', rpc('gp_passes', (c) => ({ p: c.q })));
  on('GET', '/api/passes/:t/:id/attachment', async (c) => {
    const a = await call(c, 'gp_attachment', { p_id: +c.p[1] || 0 });
    const data = await blobs.get(a.path);
    if (!data) throw new HttpError(404, 'The attachment file could not be found in storage.');
    return fileResponse(data, a.name, a.type || 'application/octet-stream');
  });
  on('GET', '/api/passes/:t/:id', rpc('gp_pass', (c) => ({ p_type: c.p[0], p_id: +c.p[1] || 0 })));
  on('GET', '/api/approvals/pending', rpc('gp_pending', (c) => ({ p_type: c.q.type || null })));
  on('GET', '/api/approvals/counts', rpc('gp_counts'));
  on('GET', '/api/approvals/history', rpc('gp_history', (c) => ({ p: c.q })));
  on('POST', '/api/approvals/bulk', rpc('gp_bulk', (c) => ({ p: c.b })));
  on('POST', '/api/approvals/:t/:id/:a', rpc('gp_act', (c) => ({ p_type: c.p[0], p_id: +c.p[1] || 0, p_action: c.p[2], p_stage: c.b.stage || null, p_remarks: c.b.remarks || null })));
  on('GET', '/api/today', rpc('gp_today', (c) => ({ p: c.q })));
  on('GET', '/api/verify', rpc('gp_verify', (c) => ({ p: c.q })));
  on('GET', '/api/reports', rpc('gp_reports', (c) => ({ p: c.q })));
  on('GET', '/api/reports/export-rows', rpc('gp_report_export', (c) => ({ p: c.q })));
  on('GET', '/api/dashboard', rpc('gp_dashboard'));

  on('GET', '/api/employees/template', () => fileResponse(csv([['Staff ID', 'Employee Name', 'Designation', 'Section/Department']]), 'Employee_Upload_Template.csv', 'text/csv; charset=utf-8'));
  on('GET', '/api/employees/export', async (c) => fileResponse(csv([['Staff ID', 'Employee Name', 'Designation', 'Section/Department', 'Status'], ...(await call(c, 'gp_employees_export'))]), `Employees_${todayDhaka()}.csv`, 'text/csv; charset=utf-8'));
  on('GET', '/api/employees', rpc('gp_employees', (c) => ({ p: c.q })));
  on('GET', '/api/employees/:id', rpc('gp_employee', (c) => ({ p_id: +c.p[0] || 0 })));
  on('POST', '/api/employees', rpc('gp_employee_save', (c) => ({ p_id: null, p: c.b })));
  on('PUT', '/api/employees/:id', rpc('gp_employee_save', (c) => ({ p_id: +c.p[0] || 0, p: c.b })));
  on('POST', '/api/employees/:id/status', rpc('gp_employee_set_status', (c) => ({ p_id: +c.p[0] || 0, p_status: c.b.status })));
  on('DELETE', '/api/employees/:id', rpc('gp_employee_delete', (c) => ({ p_id: +c.p[0] || 0 })));
  on('POST', '/api/employees/import/preview-rows', async (c) => ({ filename: String(c.b.filename || '').slice(0, 200), ...(await call(c, 'gp_import_preview', { p_rows: c.b.rows || [], p_create_departments: !!c.b.create_departments })) }));
  on('POST', '/api/employees/import/commit', rpc('gp_import_commit', (c) => ({ p_rows: c.b.rows || [], p_create_departments: !!c.b.create_departments, p_mode: c.b.mode || 'upsert' })));
  on('POST', '/api/employees/import/error-report', (c) => fileResponse(csv([['Row', 'Staff ID', 'Employee Name', 'Designation', 'Section/Department', 'Errors'], ...(c.b.items || []).slice(0, 20000).map((x) => [x.row, x.staff_id, x.name, x.designation, x.department, (x.errors || []).join('; ')])]), 'Employee_Import_Errors.csv', 'text/csv; charset=utf-8'));

  on('GET', '/api/meta/permissions', rpc('gp_meta_permissions'));
  on('GET', '/api/users', rpc('gp_users', (c) => ({ p: c.q })));
  on('POST', '/api/users', rpc('gp_user_create', (c) => ({ p: c.b })));
  on('PUT', '/api/users/:id', rpc('gp_user_update', (c) => ({ p_id: c.p[0], p: c.b })));
  on('POST', '/api/users/:id/reset-password', rpc('gp_user_reset_password', (c) => ({ p_id: c.p[0], p: { password: c.b.password, confirm_password: c.b.confirm_password, must_change_password: c.b.must_change_password === true } })));
  on('POST', '/api/users/:id/status', rpc('gp_user_set_status', (c) => ({ p_id: c.p[0], p_status: c.b.status })));

  on('GET', '/api/settings', rpc('gp_settings_get'));
  on('PUT', '/api/settings', rpc('gp_settings_put', (c) => ({ p: c.b })));
  on('POST', '/api/departments', rpc('gp_department_add', (c) => ({ p: c.b })));
  on('PUT', '/api/departments/:id', rpc('gp_department_update', (c) => ({ p_id: +c.p[0] || 0, p: c.b })));
  on('GET', '/api/logs', rpc('gp_logs', (c) => ({ p: c.q })));

  on('GET', '/api/backup/part', rpc('gp_backup_part', (c) => ({ p: c.q })));
  on('POST', '/api/backup/import', rpc('gp_backup_import', (c) => ({ p_data: c.b.data || {}, p_opts: c.b.opts || {} })));
  on('POST', '/api/backup/attach', async (c) => {
    // check the permission first (cheap), then store the file
    await call(c, 'gp_settings_get');
    const up = await storeFile(c.b.file);
    if (!up) throw new HttpError(400, 'No file.');
    return call(c, 'gp_backup_attach', { p_pass_no: String(c.b.pass_no || ''), p_path: up.path, p_name: up.name, p_type: up.type });
  });

  // ---------- request handling ----------
  return async function handle(req) {
    const started = Date.now();
    const url = new URL(req.url);
    const method = req.method.toUpperCase();
    if (method === 'OPTIONS') return new Response(null, { status: 204, headers: BASE_HEADERS });   // no cross-origin access is granted
    const secure = url.protocol === 'https:';
    const ip = (req.headers.get('x-nf-client-connection-ip') || req.headers.get('x-forwarded-for') || '').split(',')[0].trim().slice(0, 60);
    const token = cookieValue(req, COOKIE);
    const c = { req, ip, secure, tokenHash: /^[A-Za-z0-9_-]{40,60}$/.test(token) ? sha256(token) : null, q: Object.fromEntries(url.searchParams), b: {}, p: [], setCookie: null };
    try {
      if (method !== 'GET' && method !== 'HEAD') {
        // CSRF protection: browsers cannot add this header to cross-site form posts; the session cookie is also SameSite=Strict
        if (req.headers.get('x-requested-with') !== 'GatePass') throw new HttpError(403, 'Request blocked (missing security header).');
        const origin = req.headers.get('origin');
        if (origin && origin !== url.origin) throw new HttpError(403, 'Cross-site request blocked.');
        const len = +(req.headers.get('content-length') || 0);
        if (len > MAX_JSON + 1024 * 1024) throw new HttpError(413, 'The request is too large.');
        const ct = req.headers.get('content-type') || '';
        if (ct.includes('multipart/form-data')) { const fd = await req.formData(); for (const [k, v] of fd.entries()) c.b[k] = v; }
        else if (ct.includes('application/json')) { const t = await req.text(); if (t.length > MAX_JSON) throw new HttpError(413, 'The request is too large.'); c.b = t ? JSON.parse(t) : {}; }
        if (!c.b || typeof c.b !== 'object' || Array.isArray(c.b)) c.b = {};
      }
      let route = null;
      for (const [m, re, fn] of R) { const mm = re.exec(url.pathname); if (mm && (m === method || (m === 'GET' && method === 'HEAD'))) { route = fn; c.p = mm.slice(1).map((x) => decodeURIComponent(x)); break; } }
      if (!route) throw new HttpError(404, 'API endpoint not found.');
      const out = await route(c);
      const res = out instanceof Response ? out : json(200, out);
      if (c.setCookie) res.headers.append('Set-Cookie', c.setCookie);
      return res;
    } catch (e) {
      if (e instanceof SyntaxError) e = new HttpError(400, 'Invalid request body.');
      if (!(e instanceof HttpError)) { log.error('[api]', method, url.pathname, e?.stack || e); e = new HttpError(500, 'Unexpected server error. Please try again.'); }
      if (e.status >= 500) log.error('[api]', method, url.pathname, e.status, e.message, `${Date.now() - started}ms`);
      const res = json(e.status, { error: e.message, ...(e.extra || {}) });
      if (c.setCookie) res.headers.append('Set-Cookie', c.setCookie);
      if (e.status === 401 && c.tokenHash && !/\/auth\/login$/.test(url.pathname)) res.headers.append('Set-Cookie', clearCookie(secure));
      return res;
    }
  };
}

export { LABELS, csv };
