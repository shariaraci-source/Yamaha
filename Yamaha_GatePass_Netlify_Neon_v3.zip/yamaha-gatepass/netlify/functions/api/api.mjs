// Netlify Function entry point – serves every /api/* request of the Gate Pass System.
// Secrets come only from Netlify environment variables (never sent to the browser):
//   DATABASE_URL (or NETLIFY_DATABASE_URL)  – Neon connection string
//   SETUP_CODE                              – one-time code for creating the first administrator
import { neon } from '@neondatabase/serverless';
import { getStore } from '@netlify/blobs';
import { createHandler } from './core.mjs';

let handler = null;
function init() {
  const url = process.env.DATABASE_URL || process.env.NETLIFY_DATABASE_URL;
  if (!url) return null;
  const sql = neon(url);
  const store = getStore({ name: 'pass-attachments', consistency: 'strong' });
  return createHandler({
    query: (text, params) => sql.query(text, params),
    blobs: {
      set: (key, data, opts) => store.set(key, data, opts),
      get: (key) => store.get(key, { type: 'arrayBuffer', consistency: 'strong' }),
    },
    env: (k) => process.env[k],
    log: console,
  });
}

export default async (req) => {
  if (!handler) handler = init();
  if (!handler) {
    console.error('[api] DATABASE_URL is not set');
    return new Response(JSON.stringify({ error: 'The server is not connected to the database yet (DATABASE_URL is missing). See the deployment guide.' }), { status: 503, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' } });
  }
  return handler(req);
};

export const config = { path: '/api/*' };
