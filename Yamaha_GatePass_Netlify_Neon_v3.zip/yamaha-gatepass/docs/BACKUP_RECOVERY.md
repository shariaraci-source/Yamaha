# Backup & Recovery (Netlify + Neon)

Data lives in two places: the **Neon PostgreSQL database** (everything except files) and **Netlify Blobs** (attachment files). Don't rely only on the providers.

## What the free plans give you
- **Neon Free**: point-in-time restore for the last **6 hours** only, plus 1 manual snapshot. Data is not deleted when a quota runs out (the compute just stops until next month).
- **Netlify Blobs**: files stay with the site. There is no separate backup, so include them in your backup files (below).
- Paid Neon plans keep 7–30 days of restore history.

## Three layers of backup

| Layer | Contents | How | When |
|---|---|---|---|
| 1. Application backup (JSON) | Departments, employees, all gate passes, approval history, settings, users **without passwords**, activity log | Settings → Backup → **Download Backup** | **Every working day** |
| 1b. Same, **with attachment files** | as above + all attachment files embedded | Settings → Backup → **Download Backup with Attachment Files** | **Weekly** |
| 2. Excel exports | Gate passes (Reports → Export Excel) and employees | one click | Monthly / before audits |
| 3. Full database dump | complete PostgreSQL schema + data | `pg_dump` (below) or a Neon snapshot | Monthly and before every update |

Keep copies in two places outside the cloud (e.g. a USB drive held by HR & Admin and a company network folder). Keep at least 30 daily, 12 weekly and 12 monthly files. Backup files contain personal data, so restrict access to them.

### Full database dump (layer 3)
On a PC with PostgreSQL client tools installed (version ≥ your Neon version):
```bash
pg_dump "postgresql://neondb_owner:...@ep-xxxx.us-east-2.aws.neon.tech/neondb?sslmode=require" -Fc -f gatepass_YYYYMMDD.dump
```
Use the **non-pooled** connection string from Neon → Connect (pooling OFF) for `pg_dump`/`pg_restore`. Alternatively: Neon console → **Backup & Restore → Create snapshot**.

## Recovery

### A. Some records lost or changed by mistake
Settings → Backup → **Import Backup** with the latest good file. The import only **adds** what is missing (departments, employees, gate passes with original numbers, approvals, log entries, attachment files). It never overwrites or deletes existing records. A confirmation dialog explains this first, and a summary appears afterwards. Download a fresh backup before importing.

### B. Mistake noticed within 6 hours (Neon Free)
Neon console → **Backup & Restore** → restore the `main` branch to a time before the mistake (or create a branch from that time to look first). This affects all data changed since then, so prefer A when possible.

### C. Neon project lost / moving to a new project
1. Create a new Neon project and run `db/migrations/001_gatepass_schema.sql` (DEPLOYMENT_GUIDE §1).
2. Put the new connection string in Netlify `DATABASE_URL` and redeploy.
3. Run the first-administrator setup (needs `SETUP_CODE`).
4. Settings → Backup → Import the newest **backup with attachment files**, then recreate the user accounts listed after the import.
   For an exact copy instead: `pg_restore --no-owner -d "<new connection string>" gatepass_YYYYMMDD.dump`. Attachment files then still have to come from a backup-with-files import, or from the same Netlify site.

### D. Netlify site broken after an update
Netlify → Deploys → choose the previous deploy → **Publish deploy**. The database is not affected.

### E. Quota exhausted (site or database stops near month end)
No data is lost. Upgrade the plan or wait for the monthly reset; see DEPLOYMENT_GUIDE "Free-plan limits".
