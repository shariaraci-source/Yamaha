# Deployment Guide – Netlify + Neon PostgreSQL

Yamaha Factory Gate Pass System · ACI Motors Limited · Yamaha Manufacturing Plant, Sreepur, Gazipur

Time needed: about 30–45 minutes. Every step happens in **your** Netlify and Neon accounts, in your own browser. You never paste a password or secret into any website file. Secrets go only into Netlify's **Environment variables** screen.

---

## 0. What runs where

| Part | Service | Folder in this project |
|---|---|---|
| Website (the Gate Pass screens) | Netlify static hosting | `public/` |
| Backend API (`/api/*`): login, approvals, reports, uploads… | Netlify Functions | `netlify/functions/api/` |
| Central database (single source of truth) | Neon PostgreSQL | `db/migrations/001_gatepass_schema.sql` |
| Attachment files | Netlify Blobs (built into Netlify, no setup) | – |

Browsers never connect to the database. Only the Netlify Function does, using the secret `DATABASE_URL`.

### Free-plan limits (checked 6 November 2026, so confirm them on the pricing pages)

| | Neon Free | Netlify Free |
|---|---|---|
| Storage | 1 GB per project | Blobs storage included |
| Compute | 100 CU-hours / month; sleeps after 5 min idle | 300 credits / month (shared by requests, function time, bandwidth, deploys at 15 credits each) |
| Backups | 6-hour restore window, 1 manual snapshot | – |
| Request size | – | 6 MB per function call, so **attachments are limited to 4 MB** |

Rough capacity on the free plans: one gate-pass row is about 2 KB, so 1 GB holds hundreds of thousands of passes. The limit you will meet first is **Netlify credits**. Each open Gate Pass screen checks for changes every 15 seconds and uses roughly **25 credits per month** if kept open 8 hours a day, 26 days a month. Screens pause automatically after 30 minutes without mouse/keyboard use, and hidden tabs don't poll. So the free plan suits up to about 8 screens that stay open all day, plus normal use. For more, either set **Settings → Gate Pass Options → auto-refresh** to 30 seconds (halves the cost) or move to Netlify Personal (US $9/month, 1,000 credits). If credits run out on the free plan, Netlify suspends the site until the next month. Watch **Netlify → Usage**.

---

## 1. Create the Neon database

1. Go to <https://console.neon.tech> and sign up or log in (Google/GitHub login is fine).
2. **New Project**:
   - Name: `yamaha-gatepass`
   - Postgres version: the default (16 or 17)
   - **Region: AWS US East 2 (Ohio)**. Netlify runs functions in Ohio by default, so the database answers fastest from there. Region changes on Netlify are a paid feature.
3. When the project opens, choose **SQL Editor** (left menu).
4. Open `db/migrations/001_gatepass_schema.sql` from this project in Notepad, select all, copy, paste into the SQL Editor, click **Run**.
   - Expected: the run finishes without a red error.
   - It creates all tables, keys, constraints, indexes, the login/session tables and the approval workflow functions. It inserts **no users, employees or gate passes**, only roles, permissions and default settings.
5. Check: run `select public.gp_health();`. You should see `"database": "connected"` and `"schema_versions": ["001_gatepass_schema"]`.
6. **Get the connection string** (keep it secret): **Dashboard → Connect**. Choose your branch `main`, database `neondb`, role `neondb_owner`, and switch **Connection pooling ON**. Copy the string. It looks like
   `postgresql://neondb_owner:••••@ep-xxxx-pooler.us-east-2.aws.neon.tech/neondb?sslmode=require`

> Run the migration file only once. If it says something "already exists", the database is already set up. Do not delete anything; see **Updating** below.

## 2. Put the project on GitHub (recommended way to deploy)

Netlify must *build* the function, which drag-and-drop deploys don't do. Use GitHub (or the CLI in §3b).

1. Create a free account at <https://github.com> if you don't have one, then **New repository** → name `yamaha-gatepass` → **Private** → Create.
2. On the new repository page click **uploading an existing file**, then drag **the contents** of the unzipped project folder (`public`, `netlify`, `db`, `docs`, `tests`, `netlify.toml`, `package.json`, `.gitignore`, `README.md`) → **Commit changes**.

## 3a. Connect Netlify to the repository

1. <https://app.netlify.com> → **Add new project → Import an existing project → GitHub** → authorise Netlify (official GitHub login window) → pick `yamaha-gatepass`.
   - To keep your **existing Netlify site and URL**, open that site instead → **Project configuration → Build & deploy → Continuous deployment → Link repository**.
2. Build settings are read from `netlify.toml` automatically (publish `public`, functions `netlify/functions`). Leave them as shown.
3. Before the first deploy, or right after it, add the environment variables (§4), then **Deploys → Trigger deploy → Deploy project**.

## 3b. Alternative: deploy from your PC with the Netlify CLI

Needs Node.js 20+ on the PC.
```bash
cd yamaha-gatepass            # the unzipped project folder
npm install
npx netlify-cli login         # opens the official Netlify login page in your browser
npx netlify-cli link          # choose your existing site (or: npx netlify-cli init to create one)
npx netlify-cli env:set DATABASE_URL "postgresql://...your Neon string..." --secret
npx netlify-cli env:set SETUP_CODE "YGP-7F3K-91QX" --secret
npx netlify-cli deploy --build --prod
```

## 4. Environment variables (Netlify → Project configuration → Environment variables)

| Key | Value | Notes |
|---|---|---|
| `DATABASE_URL` | the Neon pooled connection string from §1.6 | Required. Tick **Contains secret values**; scope: Functions. Never put it in any file. |
| `SETUP_CODE` | a code you invent, e.g. `YGP-7F3K-91QX` | Required for the one-time first-administrator setup. Write it down. You may delete it after setup. |

That's all. `NETLIFY_DATABASE_URL` is also accepted instead of `DATABASE_URL` if you connect Neon through Netlify's own database integration. Netlify Blobs needs no variables. After adding or changing variables, **redeploy** (Deploys → Trigger deploy).

## 5. Check the deployment

1. Open `https://<your-site>.netlify.app/api/health`. You should see `{"database":"connected", …, "schema_versions":["001_gatepass_schema"]}`.
   - `DATABASE_URL is missing` means §4 isn't done or there was no redeploy.
   - `database is not reachable` means the connection string is wrong, or the Neon project is suspended (free compute used up).
2. Open `https://<your-site>.netlify.app/`. On an empty database the **Initial System Setup** screen appears.

## 6. Create the first administrator (once)

1. On the setup screen enter the **SETUP_CODE**, your **User ID**, **name**, a **password** (at least 10 characters, letters and numbers, not containing the User ID), and your **departments** (one per line, optionally `Name | CODE`).
2. **Complete Setup & Log In.** You land on the dashboard.
3. The setup screen is now closed for good. A second attempt is refused by the server, even with the correct code.

Then follow **ADMIN_GUIDE.md**: employees (Excel import), Department Heads with their departments, HR & Admin, Factory Head, Security.

## 7. Bring over existing data (optional)

From the **old single-PC version** or the **Supabase cloud version**: in the old system go to **Settings → Backup → Download Backup** (`.json`, preferably "with attachment files"). In the new system go to **Settings → Backup → Import Backup**. It's a safe merge: original Gate Pass Numbers, approval history and the activity log are kept; nothing that already exists is overwritten. User accounts must be recreated, because passwords are never exported; the import lists them for you.

## 8. Live-system checklist

See **LIVE_CHECKLIST.md**. Work through it once with two computers before announcing the URL to staff.

## 9. Updating later

- **Code changes**: commit to GitHub, and Netlify redeploys automatically. Data in Neon is untouched; logged-in users stay logged in.
- **Database changes**: future updates come as new files `db/migrations/002_….sql`. Run only the new file in the Neon SQL Editor. Never re-run `001`. `select public.gp_health();` lists the applied versions.
- Download a backup (Settings → Backup) before every update.
- Rollback of the website: Netlify → Deploys → choose an earlier deploy → **Publish deploy**.

## Troubleshooting

| Symptom | Fix |
|---|---|
| Page says "cannot connect to the central database" / every action fails | Open `/api/health` and follow the message there (§5). |
| Setup says "setup code has not been configured" | Add `SETUP_CODE` (§4) and redeploy. |
| "The one-time setup code is not correct" | Check spelling (it isn't case-sensitive), or the variable was changed without a redeploy. |
| Site suddenly offline near month end | Netlify free credits used up, or Neon compute hours used up. Check Usage in both dashboards; upgrade or wait for the monthly reset. No data is lost. |
| Attachment refused | Max 4 MB; PDF, JPG, PNG, XLSX, DOCX only; the file content must match its extension. |
| Header pill shows "Paused – move the mouse" | Normal after 30 minutes without use. Any movement resumes live updates. |
