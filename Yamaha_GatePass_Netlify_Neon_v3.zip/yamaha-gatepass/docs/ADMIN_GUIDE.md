# Administrator Setup Guide

For the System Administrator of the Yamaha Factory Gate Pass System (Netlify + Neon edition).

## 1. Create the first administrator (once)

1. Open the site URL. On an empty database the **Initial System Setup** screen opens automatically.
2. Enter the **one-time setup code** (the `SETUP_CODE` environment variable set in Netlify during deployment).
3. Choose your **User ID**, **Full Name**, **Designation** and a **password** (at least 10 characters, letters and numbers, must not contain the User ID).
4. Edit the **Sections / Departments** list – one per line, optionally `Name | CODE`, e.g. `Paint Shop | PAINT`. Names must match the *Section/Department* column of your employee Excel file.
5. **Complete Setup & Log In.** After this the setup screen is permanently closed; nobody can create a second "first administrator".

The dashboard now shows a **Getting Started** checklist. Work through it in this order.

## 2. Departments

**Settings → Departments**: add, rename, activate/deactivate. Departments are never deleted, so old gate passes keep their department. Deactivated departments cannot be chosen for new employees.

## 3. Employee database

**Employee Database** (menu *Administration*):
- **Download Template** → fill columns *Staff ID, Employee Name, Designation, Section/Department* in Excel → **Upload Excel** (.xlsx or .csv).
- The upload shows a **preview**: New / Update / Unchanged / Errors (e.g. duplicate Staff ID in the file, unknown department). Nothing is saved until you click **Import**. Choose *Add new and update existing* or *Only add new*; optionally create missing departments.
- **Add Employee**, **Edit**, **Deactivate/Activate**, **Delete** (only for employees without gate pass history – otherwise deactivate).
- **Export** downloads the full list (opens in Excel).

Employees do **not** need logins – they request gate passes with their Staff ID.

## 4. User accounts and roles

**User Management → Create New User**. Fill User ID (3–60 characters: letters, numbers, `. _ - @`), name, designation, password (≥ 8 characters with letters and numbers) and pick a **User Role** – the matching permissions are ticked automatically and can be adjusted.

| Role | Typical rights |
|---|---|
| System Administrator | Employees, users, settings, reports, Excel import/export (no approval rights unless ticked) |
| Section/Department Head | Stage 1 approval **only for the departments ticked** under *Approval Assignment*; usually sees only those departments |
| HR & Admin Approver | Stage 2 approval for all departments (final for Employee Gate Passes) |
| Factory Head | Stage 3 (final) approval of Material Gate Passes |
| Security Personnel | Today's Gate Pass + gate verification (read-only, printing) |
| Concerned Viewer | Today's Gate Pass (read-only) |

Other options:
- **Approval Assignment** – departments a Department Head may approve. Several heads may share a department (the first decision wins; the other sees "already processed").
- **Data visibility** – *All departments* or *Only assigned / own department(s)*.
- **Linked Staff ID** – stops the person approving their own gate pass.
- **Settings → Gate Pass Options → Require different persons for each stage** – the same person can never approve two stages of one request.

### Mandatory password change – only when you choose it
- When creating a user, the box **"User must change password at next login"** is **unticked by default**. Leave it unticked and the user logs in straight to the dashboard. Tick it only if you want the user to replace the password you gave them.
- Users can always change their own password from their **profile menu → Change Password**.

### Reset a password
**User Management → Reset** on the user's row → new password + confirm → optionally tick **"User must change password at next login"**.
- The user is **signed out on every computer immediately**.
- Nobody, including you, can see any existing password (passwords are stored only as bcrypt hashes in the database).

### Deactivate / activate
**Deactivate** blocks the login and signs the user out everywhere at once. History stays. You cannot deactivate yourself or remove your own User Management permission.

## 5. Settings

- **Company & Print** – company/plant names (English and Bengali), address, system title, **logo** (PNG/JPG/SVG/WEBP ≤ 300 KB) – used in the header and on printed gate passes. *Preview Printed Gate Pass* shows the layout.
- **Gate Pass Options** – material categories, units, distinct-approver rule, auto-refresh interval (how often open screens check for changes; default 15 s, 30 s halves the Netlify usage).
- **Backup** – see `BACKUP_RECOVERY.md`.
- **Activity Log** – every login (including failed ones), submission, approval/rejection, gate verification, user change, password reset/change, import, export and backup.

## 6. Daily checks (2 minutes)
- Dashboard warnings: departments without an active Department Head, no active Factory Head.
- Header pill **Live** (green) = connected; changes from other computers appear within about 15 seconds. "Paused – move the mouse" after 30 minutes without use is normal.
- Locked-out user (5 wrong passwords): they can try again after 15 minutes, or you can reset their password.
- Download the daily backup (Settings → Backup).
