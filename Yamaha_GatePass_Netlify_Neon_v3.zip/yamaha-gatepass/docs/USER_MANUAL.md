# User Manual – Yamaha Factory Gate Pass System

Open the Gate Pass website address given by your administrator in Google Chrome or Microsoft Edge. Every computer uses the same address and sees the same, up-to-date information. The small pill at the top right shows **Live** (green) when connected; changes made on other computers appear within about 15 seconds. If the internet drops, a red banner appears and the page reconnects by itself. After 30 minutes without use the pill shows "Paused – move the mouse": just move the mouse.

---

## A. Employees – request a gate pass (no login needed)

### Employee Gate Pass (leaving the factory for a short time)
1. Home → **Create Employee Gate Pass**.
2. Type your **Staff ID** and press Enter – your name, designation and department fill in automatically. If the ID is not found or inactive, contact HR & Admin.
3. Write the **Reason**, choose **Out Time** and **In Time** (In must be later than Out).
4. **Submit Request**. Note your **Gate Pass Number** (e.g. `EGP-20261104-0001`).
5. Approval order: **Department Head → HR & Admin**.

### Material Gate Pass (goods leaving the factory)
1. Home → **Create Material Gate Pass**.
2. Your Staff ID, **Material Category**, **Material Name**, **Quantity + Unit**, description, **Reason**, **Destination / Recipient**, **Out Time**. Tick *Returnable* and give the expected return date/time if the material comes back.
3. Optional **attachment** (challan, invoice, photo): PDF, JPG, PNG, XLSX or DOCX, maximum **4 MB**.
4. **Submit Request** and note the number (e.g. `MGP-20261104-0001`).
5. Approval order: **Department Head → HR & Admin → Factory Head**.

Clicking Submit twice does not create two requests.

### Track your request
Home → **Track My Request** → Gate Pass Number + Staff ID. You see each stage (who approved and when, or the rejection reason). Once **Approved – Fully Approved**, you can **Print Gate Pass** (two copies: Security and Employee).

---

## B. Staff – log in
1. **Staff Login** (left menu or top right).
2. Enter your **User ID** and **Password** → you go straight to your **Dashboard**.
3. You are asked to change the password at login **only** if the administrator required it for your account.
4. Forgot your password? Ask the System Administrator to reset it. After 5 wrong passwords the login is blocked for 15 minutes.
5. **Logout**: profile menu (top right) → Logout, or *Logout* in the left menu. You are logged out automatically after 8 hours without activity.

### Change your own password (any time)
1. Click your **name** (top right) → **Change Password**.
2. Enter **Current Password**, **New Password**, **Confirm New Password**.
3. Rules: at least **8 characters**, **letters and numbers**, different from the current password.
4. **Update Password** → "Your password has been changed successfully." Use the new password next time. Any other computer where you were logged in is signed out.

---

## C. Approvers

### Department Head (stage 1)
- **Pending Approvals** shows requests from **your assigned departments only**. New requests appear by themselves within about 15 seconds – no need to refresh.
- **Approve**: one click (no remarks needed).
- **Reject**: a reason is **mandatory**.
- **View** (eye icon) shows all details, attachment and approval history.
- Several requests: tick them → **Approve Selected** / **Reject Selected**.

### HR & Admin (stage 2)
- **Pending Approvals → Pending for HR & Admin Approval** – requests already approved by a Department Head, from all departments.
- Approving an **Employee** Gate Pass makes it valid. Approving a **Material** Gate Pass sends it to the Factory Head.

### Factory Head (stage 3 – Material only)
- **Pending Factory Head Approval** – your approval completes the Material Gate Pass.

**Approved Requests** shows what you decided (approved or rejected). A request can never skip a stage, and nobody can decide a request that is not at their stage or outside their departments.

---

## D. Security at the gate
1. Open **Today's Gate Pass** – only **fully approved** passes for today are listed.
2. **Gate Verification**: type the Gate Pass Number or Staff ID → **Verify**.
   - Green **AUTHORIZED TO LEAVE** with the approvers' names, or
   - Red **NOT AUTHORIZED** (pending, rejected or not found).
3. **Print List** prints today's approved passes.

---

## E. Reports (authorised users)
**Reports** → choose filters (dates, type, status, department, staff, approvers, material category) → **Search**. Tabs: Records, Department-wise, Date-wise. **Export Excel** downloads exactly the filtered records; **Print** prints them.
