# What changed in version 3 (Netlify + Neon)

## Kept unchanged
All screens, menus, colours, logo, Bengali/English print layout, forms and dashboards. The approval sequences are identical:
- Employee Gate Pass: Department Head → HR & Admin → Fully Approved
- Material Gate Pass: Department Head → HR & Admin → Factory Head → Fully Approved

Also unchanged: mandatory rejection remarks; no stage skipping; no duplicate approvals; department-restricted approvers; self-approval and same-person multi-stage approval blocks; roles and permissions; mandatory password change only when the administrator ticks it; Excel import/export; reports; printing; audit log; backup/merge-import (including old single-PC backups). All of the business rules are the same database code as before.

## Replaced (Supabase removed)

| Before (Supabase) | Now |
|---|---|
| Supabase PostgreSQL | **Neon PostgreSQL** (same schema, same business-rule functions) |
| Supabase Auth | Own login in the database: **bcrypt** password hashes (pgcrypto), random session tokens stored only as **SHA-256** hashes, **HttpOnly + Secure + SameSite=Strict** cookie |
| Browser → database via Supabase API + Row Level Security | Browser → **Netlify Function `/api/*`** → database. The function calls one database entry point (`api_call`) that checks the session and allows only a fixed list of functions |
| Edge Function `admin-users` | Moved into the database functions (user create/edit, reset, deactivate, change password, first-admin setup) |
| Supabase Storage | **Netlify Blobs** (private; files are served only after the database confirms the viewer may see the gate pass) |
| Supabase Realtime (websocket) | **Change polling**: each open screen asks a tiny endpoint every 15 s whether anything changed and refreshes only then |
| `config.js` with public keys | Not needed: no keys in the website at all |

## Changes you will notice (necessary for the new platform)
1. **Attachment limit is 4 MB** (was 5 MB). Netlify functions accept at most 6 MB per request, and files are Base64-encoded in transit (+33 %). Larger scans should be saved at a lower resolution or as PDF.
2. **Updates from other computers arrive within about 15 seconds** (was about 1–2 seconds). Your own actions still show immediately. The interval can be changed in Settings → Gate Pass Options (10–600 s); shorter intervals use more of the free quota.
3. **Live updates pause after 30 minutes without mouse/keyboard activity** (pill shows "Paused – move the mouse") and resume instantly on activity. This lets the database sleep at night and protects the free quotas.
4. **Login protection**: 5 wrong passwords for one User ID (or 25 from one network address) within 15 minutes block further attempts for 15 minutes.
5. **Sessions**: automatic logout after 8 hours without activity (enforced by the server), and at the latest after 72 hours. Changing your own password signs out your other computers. A reset or deactivation by the administrator signs the user out everywhere.
6. **Uploaded files are checked by content**, not only by extension. A program renamed to `.pdf` is refused.
7. **Backups are produced in parts** behind the scenes (same file format as before), so very large databases can still be backed up within Netlify's size limits.
