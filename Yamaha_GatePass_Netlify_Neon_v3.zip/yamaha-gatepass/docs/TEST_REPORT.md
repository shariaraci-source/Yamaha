# Test Report – Netlify + Neon edition

Date: 6 November 2026 · Result: **91 of 91 checks passed** on the final code. The browser suite also passed three times in a row on the version just before the final idle-pause change, and twice more on the final code.

## How it was tested
- **Database:** the real migration `db/migrations/001_gatepass_schema.sql` on **PostgreSQL 16**, applied and used by a **non-superuser owner role** (like Neon's `neondb_owner`), on an empty database with no Supabase objects.
- **Backend:** the real Netlify Function code (`netlify/functions/api/core.mjs`) handled every `/api/*` request: login, sessions, approvals, uploads, downloads, backups.
- **Frontend:** the real `public/index.html` in **Google Chrome**, with up to 9 separate browser profiles acting as different computers (admin, two Department Heads of one department, another department's head, HR & Admin, Factory Head, Security, an employee kiosk, and a forced-password-change user). All shared one central database.
- **Redeployment:** the server process was restarted mid-test (equivalent to a new Netlify deploy). Records and existing logins survived.

### Stand-ins used only for testing
This build environment has no internet access, so three thin pieces were simulated:

| In production | In the test |
|---|---|
| `@neondatabase/serverless` (Neon's HTTP driver) | `psql` running the exact same SQL statement with the same parameters |
| `@netlify/blobs` | a local folder |
| Netlify's routing of `/api/*` to the function | a small Node web server calling the same handler |

The production entry file `netlify/functions/api/api.mjs` (about 30 lines connecting these two libraries) is therefore **not exercised here**. It will run for the first time on your Netlify deploy. `/api/health` and the LIVE_CHECKLIST confirm it within minutes.

## Bugs found and fixed during this migration
1. A dialog's automatic focus could, on a slow machine, land while the automated tester was typing. This is a test-timing issue, not reachable by a person (focus moves 30 ms after a dialog opens); the tests now wait for dialogs to settle.
2. Open screens would have kept polling all night, which keeps the free Neon compute awake and uses Netlify credits. Polling now pauses after 30 minutes without activity and resumes on any mouse/keyboard input.

## Results

| # | Check | Result |
|---|---|---|
| 1 | Open the URL on PC 1 → application loads (first start shows Initial Setup) | ✅ Pass |
| 2 | Initial administrator created through secure setup (setup code required) → dashboard | ✅ Pass |
| 3 | Initial setup cannot be run a second time | ✅ Pass |
| 4 | Excel/CSV import preview validates rows (duplicate Staff ID flagged) | ✅ Pass |
| 5 | Employees imported into the central database | ✅ Pass |
| 6 | Employee added manually (Employee Database) | ✅ Pass |
| 7 | PC 1: administrator created 7 users (roles, departments, approval rights) | ✅ Pass |
| 8 | New users without the flag are NOT marked for a forced password change | ✅ Pass |
| 9 | Server rejects passwords without letters AND numbers | ✅ Pass |
| 10 | Open the same URL on PC 2 → same application and database (new user from PC 1 can log in) | ✅ Pass |
| 11 | Normal user login → no forced password-change screen | ✅ Pass |
| 12 | Staff ID verification auto-fills name / designation / department | ✅ Pass |
| 13 | Employee Gate Pass created with generated number | ✅ Pass |
| 14 | Material Gate Pass created with attachment uploaded to cloud storage | ✅ Pass |
| 15 | File upload validation rejects disallowed file types | ✅ Pass |
| 16 | A renamed program disguised as .pdf is rejected (file content check) | ✅ Pass |
| 17 | Attachments above 4 MB are refused with a clear message | ✅ Pass |
| 18 | Rejected uploads create no gate pass | ✅ Pass |
| 19 | Create a gate pass on PC 3 → record appears on PC 2 automatically (no reload, within the 15 s refresh) | ✅ Pass |
| 20 | Double-click / duplicate submission (same key) creates only ONE gate pass | ✅ Pass |
| 21 | Identical request with a new form is blocked as duplicate | ✅ Pass |
| 22 | Department Head approves on PC 2 (one click, no remarks) | ✅ Pass |
| 23 | Unauthorized user attempts approval (other department) → access denied | ✅ Pass |
| 24 | Rejection without remarks is refused by the server | ✅ Pass |
| 25 | Concurrent approval by two users → exactly one succeeds, the other gets "already processed" | ✅ Pass |
| 26 | Log out and log in as another user on PC 1 | ✅ Pass |
| 27 | Approval stages cannot be bypassed (HR cannot approve before Department Head) | ✅ Pass |
| 28 | Approve on PC 2 → updated status appears for HR & Admin on PC 1 | ✅ Pass |
| 29 | Employee Gate Pass: Dept Head → HR & Admin → Fully Approved | ✅ Pass |
| 30 | Search and filtering: by status, by employee name, by department | ✅ Pass |
| 31 | Duplicate approval is prevented | ✅ Pass |
| 32 | Material Gate Pass goes to Factory Head after HR & Admin | ✅ Pass |
| 33 | HR & Admin cannot give the Factory Head approval → access denied | ✅ Pass |
| 34 | Attachment retrieval: authorized user downloads the original file from cloud storage | ✅ Pass |
| 35 | Attachment cannot be downloaded without login | ✅ Pass |
| 36 | Material Gate Pass: Dept Head → HR & Admin → Factory Head → Fully Approved, history kept | ✅ Pass |
| 37 | Dashboard statistics come from the central database (Factory Head view) | ✅ Pass |
| 38 | Unauthorized user cannot open another department's attachment | ✅ Pass |
| 39 | Department-based data restriction (Paint Head cannot view Production pass) | ✅ Pass |
| 40 | PC 5: Security sees fully approved passes and verification says AUTHORIZED | ✅ Pass |
| 41 | Security Personnel cannot approve | ✅ Pass |
| 42 | Pending request at the gate → NOT AUTHORIZED | ✅ Pass |
| 43 | Change Password is in the user profile menu, without a forced warning | ✅ Pass |
| 44 | Wrong current password is rejected | ✅ Pass |
| 45 | New password must differ from the current one | ✅ Pass |
| 46 | Change password voluntarily → success | ✅ Pass |
| 47 | Old password no longer works | ✅ Pass |
| 48 | Login with the new password → successful | ✅ Pass |
| 49 | Mandatory password flag enabled → user must change password | ✅ Pass |
| 50 | Server blocks all data until the mandatory change is done | ✅ Pass |
| 51 | After the mandatory change the flag is cleared (next login goes to dashboard) | ✅ Pass |
| 52 | Administrator resets a password (form never shows the existing password) | ✅ Pass |
| 53 | Password reset invalidates the user's existing sessions on other PCs | ✅ Pass |
| 54 | A copied session cookie from before the reset is rejected by the server | ✅ Pass |
| 55 | Reset with flag → mandatory change screen | ✅ Pass |
| 56 | Admin cannot see passwords or hashes (no password field in user data) | ✅ Pass |
| 57 | Reset without the flag → user goes straight to the dashboard | ✅ Pass |
| 58 | Deactivated user is logged out everywhere immediately | ✅ Pass |
| 59 | Deactivated user cannot log in | ✅ Pass |
| 60 | Refresh browser → still logged in and existing records remain | ✅ Pass |
| 61 | Temporary internet disconnection → connection warning shown | ✅ Pass |
| 62 | Connection restored → automatic recovery, data loads again | ✅ Pass |
| 63 | Export reports → CSV/Excel file with correct data | ✅ Pass |
| 64 | Employee export to Excel | ✅ Pass |
| 65 | Backup contains employees, passes, approvals, users (no passwords) and attachment files | ✅ Pass |
| 66 | Restoring a backup over live data adds nothing and overwrites nothing (safe merge) | ✅ Pass |
| 67 | Single-PC edition backup migrates: keeps pass numbers + approval history, lists users to recreate | ✅ Pass |
| 68 | Migrated pass keeps number, status, approvers and Dhaka timestamps | ✅ Pass |
| 69 | Audit log records setup, logins, submissions, approvals, resets, imports | ✅ Pass |
| 70 | No database URL, password or secret in the website files | ✅ Pass |
| 71 | Every protected API endpoint refuses requests without login (401) | ✅ Pass |
| 72 | Internal functions cannot be reached through the API dispatcher (allow-list) | ✅ Pass |
| 73 | Cross-site request forgery is blocked (missing header / foreign origin) | ✅ Pass |
| 74 | A logged-in non-admin cannot use User Management (403) | ✅ Pass |
| 75 | Passwords stored only as bcrypt hashes; session tokens stored only as SHA-256 hashes | ✅ Pass |
| 76 | SQL injection attempt is treated as plain text | ✅ Pass |
| 77 | Session cookie is HttpOnly + SameSite=Strict (page scripts cannot read it) | ✅ Pass |
| 78 | Secure logout: the session cookie cannot be reused afterwards | ✅ Pass |
| 79 | After browser closure + redeployment: login works and all records are still there | ✅ Pass |
| 80 | Existing logged-in sessions survive a redeployment | ✅ Pass |
| 81 | No JavaScript errors in any browser | ✅ Pass |
| 82 | Header shows Live while the screen is in use | ✅ Pass |
| 83 | After 30 min without activity, polling stops (database may sleep) | ✅ Pass |
| 84 | Moving the mouse resumes live updates immediately | ✅ Pass |
| 85 | Health endpoint confirms database connection and migration version | ✅ Pass |
| 86 | 5 wrong passwords lock the User ID for 15 minutes (even the right password is refused) | ✅ Pass |
| 87 | After 15 minutes the user can log in again | ✅ Pass |
| 88 | Changing your own password keeps this computer logged in and signs out the others | ✅ Pass |
| 89 | New password must contain letters and numbers (server-side) | ✅ Pass |
| 90 | Session ends automatically after 8 hours without activity (server-side) | ✅ Pass |
| 91 | Unknown User ID and wrong password give the same message (no account guessing) | ✅ Pass |

## Re-running the tests (developers)
See `tests/README.md`.
