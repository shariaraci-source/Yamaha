# Live-System Verification Checklist

Do this once after deployment, with **two different computers** (or two different browsers, e.g. Chrome on PC 1 and Edge on PC 2). Tick each line.

## A. Connection
- [ ] `https://<site>/api/health` shows `"database":"connected"` and `001_gatepass_schema`
- [ ] The site opens on PC 1 and PC 2; the header pill turns green **Live** within a few seconds

## B. Accounts and passwords
- [ ] First administrator created via setup code; a second setup attempt is refused
- [ ] Admin creates a Department Head (approval department ticked), HR & Admin, Factory Head and Security user, each **without** "must change password"
- [ ] PC 2: the new Department Head logs in and goes **straight to the dashboard** (no forced password screen)
- [ ] Profile menu → Change Password with a wrong current password is refused; with the correct one it succeeds; log out and log in with the new password
- [ ] Admin resets a password **with** "must change password", and that user is signed out on their PC and must set a new password at the next login
- [ ] Admin deactivates a test user, who is signed out immediately and cannot log in

## C. Gate pass workflow across computers
- [ ] PC 1 (no login): Employee Gate Pass for a real Staff ID, with name/department filled automatically, giving number `EGP-YYYYMMDD-0001`
- [ ] PC 1: Material Gate Pass with a small PDF attachment, giving `MGP-…`
- [ ] PC 2 (Department Head, Pending Approvals open): both requests appear **without pressing refresh** (within about 15 seconds)
- [ ] PC 2: approve the employee pass; reject the material pass with no remarks, which must be refused; then approve it
- [ ] PC 1 (HR & Admin): both are now in "Pending for HR & Admin"; approve both
- [ ] Material pass now waits for the Factory Head; Factory Head opens the attachment (it downloads) and approves
- [ ] Security: Today's Gate Pass lists both; Gate Verification shows **AUTHORIZED TO LEAVE**; a pending pass shows **NOT AUTHORIZED**
- [ ] A Department Head of another department cannot see or approve these requests
- [ ] Track My Request (Gate Pass No. + Staff ID) shows every stage with names and times

## D. Data and reports
- [ ] Dashboard numbers match what you created
- [ ] Reports: filter by date/department/status; **Export Excel** opens in Excel with the same rows
- [ ] Employee Database: Excel template import preview, then import; export
- [ ] Settings → Backup → Download Backup (save the file somewhere safe)

## E. Persistence
- [ ] Close every browser window, reopen, log in: everything is still there
- [ ] Trigger a redeploy in Netlify (Deploys → Trigger deploy); afterwards all data is still there and logged-in users stay logged in
- [ ] Unplug the network briefly: red "connection lost" banner, then automatic recovery when reconnected

When all boxes are ticked, give staff the URL and the USER_MANUAL.
